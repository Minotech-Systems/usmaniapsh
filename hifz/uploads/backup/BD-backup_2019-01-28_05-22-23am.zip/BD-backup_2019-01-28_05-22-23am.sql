#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8_unicode_ci NOT NULL,
  `email` longtext COLLATE utf8_unicode_ci NOT NULL,
  `password` longtext COLLATE utf8_unicode_ci NOT NULL,
  `level` longtext COLLATE utf8_unicode_ci NOT NULL,
  `authentication_key` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `admin` (`admin_id`, `name`, `email`, `password`, `level`, `authentication_key`) VALUES ('1', 'اکاونٹنٹ', 'account', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '1', '');


#
# TABLE STRUCTURE FOR: child_expense_category
#

DROP TABLE IF EXISTS `child_expense_category`;

CREATE TABLE `child_expense_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf8 NOT NULL,
  `expenses_category_id` int(11) NOT NULL,
  `comment` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('1', 'بجلی', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('2', 'گیس ایندھن', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('3', 'مطبخ', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('4', 'تنخواہ', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('5', 'خرچہ امتحانات', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('6', 'ٹیلیفون/فیکس', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('7', 'ڈاک', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('8', 'ٓامدورفت', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('9', 'سٹیشنری', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('10', 'کتب', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('11', 'العصر', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('12', 'وظائف', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('13', 'ضیافت', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('14', 'تقریبات', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('15', 'متفرقات', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('16', 'تعمیرات', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('17', 'خریداری زمین', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('18', 'مرمت بلڈنگ', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('19', 'سنیٹری', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('20', 'دفتری ٓالات', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('21', 'برقی الات', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('22', 'فرنیچر', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('23', 'ڈسپنسری', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('24', 'العصر اکیڈمی', '2', '');


#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('02647659c389722bf7c9aa3c6d098a821ebef001', '::1', '1548648154', '__ci_last_regenerate|i:1548647863;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1213a5c2ab677fea2f4fe39b4f41a269163992cb', '::1', '1548567099', '__ci_last_regenerate|i:1548566863;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('132247f0fcb9e5441e33f105b892c7cd273a8601', '::1', '1548569913', '__ci_last_regenerate|i:1548569619;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('18dc11c1f10ee6d4f2c5ffe6cf910264cb7b6266', '::1', '1548647240', '__ci_last_regenerate|i:1548647236;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1acbe7298dcb977ce24b0614a67660c17c3e9d5b', '::1', '1548647123', '__ci_last_regenerate|i:1548646837;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ebad21a166c3f9228b3693d90d8070d4ed56fda', '::1', '1548570415', '__ci_last_regenerate|i:1548570128;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1f1f2870d38c13e450aee50be001e428c86010d4', '::1', '1548573057', '__ci_last_regenerate|i:1548572777;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2749975b8e1bb84077e19790b94e6c8620ec80d3', '::1', '1548566694', '__ci_last_regenerate|i:1548566534;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('291b7ab1039dd7c0e03da260d49433e37fef8fc2', '::1', '1548571077', '__ci_last_regenerate|i:1548570790;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('30c2d044d3ea05af3244ce8dcb6e38c28982f632', '::1', '1548646360', '__ci_last_regenerate|i:1548646145;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('35f29be631d73d1de83979f34cd7daecda7815b1', '::1', '1548570716', '__ci_last_regenerate|i:1548570472;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39aed443c9a0ca45e2ce30461dc99bd851e85f8c', '::1', '1548574581', '__ci_last_regenerate|i:1548574573;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3e3fefa32acdc53b2432769bb98db1ffab262e2c', '::1', '1548567526', '__ci_last_regenerate|i:1548567240;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('429f1cbe24c475833d6607a0cc5f0ea681f8401b', '::1', '1548648303', '__ci_last_regenerate|i:1548648169;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4c898ee891161abc8c8b830ce658fb082a6297d1', '::1', '1548568259', '__ci_last_regenerate|i:1548568006;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('596aadf5174560e47d421a31a4b73f7c9ee2dba2', '::1', '1548646730', '__ci_last_regenerate|i:1548646454;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d091b71e3f51b5edd65d3d831b85fff76925380', '::1', '1548568609', '__ci_last_regenerate|i:1548568386;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('699ecc875ae8d3c84510f84534e82145981a72a3', '::1', '1548564889', '__ci_last_regenerate|i:1548564654;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6cca6925e8690ac90f6cce5952b32cd13d131425', '::1', '1548564602', '__ci_last_regenerate|i:1548564348;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6dd9cb577fae9ba9dfd7eaf4be56d7a800acd9a6', '::1', '1548581559', '__ci_last_regenerate|i:1548581559;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('76b73bcd0bfee0d3128613b772759378f3e72386', '::1', '1548648802', '__ci_last_regenerate|i:1548648505;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:25:\"Database Backup Completed\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8589ef7472ef1ac5b7996eb96e23c86bf3f9087f', '::1', '1548575126', '__ci_last_regenerate|i:1548575126;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8873732bc2a265632b336adc34f46cf02a4bbe03', '::1', '1548572687', '__ci_last_regenerate|i:1548572458;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8af98dbba8c51c6410ff20c0bdc613c1b2b6b6ea', '::1', '1548573566', '__ci_last_regenerate|i:1548573402;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('984152b4f7287c712d9665c118303897585ebbef', '::1', '1548573991', '__ci_last_regenerate|i:1548573829;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a228244eecf39e5f6fd9c3286ba85025bac82865', '::1', '1548564209', '__ci_last_regenerate|i:1548563934;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a610ad82dfe2f00a639dec538eec1d291cb7951e', '::1', '1548581571', '__ci_last_regenerate|i:1548581559;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a6a078cc4fffd93f4caedeedd6e6a1de6ef2744a', '::1', '1548572138', '__ci_last_regenerate|i:1548571851;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a7933f93940a0d536d615a2470204750fc3a0975', '::1', '1548565130', '__ci_last_regenerate|i:1548565039;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad9880fd5030ea87c10f8af0fbdfdd440b8d17bd', '::1', '1548565866', '__ci_last_regenerate|i:1548565582;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b14a1df64addf301527e296ed1f5aea1c5742edf', '::1', '1548563811', '__ci_last_regenerate|i:1548563627;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d12aa4795a3b96e28812e45c04718e1ed01fb3fc', '::1', '1548574541', '__ci_last_regenerate|i:1548574271;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d56116ee96e4664d8a9152fb15f3b031ab3ecb62', '::1', '1548573386', '__ci_last_regenerate|i:1548573093;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e8724113413dd2a492cd65e042866651b2d44fa5', '::1', '1548571786', '__ci_last_regenerate|i:1548571541;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb9a7f085647269d28dd9c74cf5d286b893af908', '::1', '1548567550', '__ci_last_regenerate|i:1548567549;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('edca16ee5b071b3e3c2bc915a5adb64bf4ad9e35', '::1', '1548566097', '__ci_last_regenerate|i:1548565888;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3c3e2a4d7a9c30cb7c16380819d74e154ed7d60', '::1', '1548571353', '__ci_last_regenerate|i:1548571118;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f73ad49dac2565ea0766e44202f566475b3bf2bf', '::1', '1548572319', '__ci_last_regenerate|i:1548572155;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fa1e8a537338660c3b7b08a4ac35def3682410a7', '::1', '1548649339', '__ci_last_regenerate|i:1548649139;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:25:\"Data Deleted Successfully\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fa68945b4c4169a8e5968889e8337d1845ef3a63', '::1', '1548566453', '__ci_last_regenerate|i:1548566196;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');


#
# TABLE STRUCTURE FOR: expenses_category
#

DROP TABLE IF EXISTS `expenses_category`;

CREATE TABLE `expenses_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf8 NOT NULL,
  `comment` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `expenses_category` (`id`, `name`, `comment`) VALUES ('1', 'واجبی اخراجات', '');
INSERT INTO `expenses_category` (`id`, `name`, `comment`) VALUES ('2', 'عمومی اخراجات', '');
INSERT INTO `expenses_category` (`id`, `name`, `comment`) VALUES ('3', 'ترقیا تی اخراجات', '');


#
# TABLE STRUCTURE FOR: income
#

DROP TABLE IF EXISTS `income`;

CREATE TABLE `income` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `income_category_id` int(11) NOT NULL,
  `bill_no` int(11) NOT NULL,
  `date` date NOT NULL,
  `assistant` longtext CHARACTER SET utf8 NOT NULL,
  `amount` int(11) NOT NULL,
  `arabic_month` int(11) NOT NULL,
  `arabic_date` date NOT NULL,
  `comment` longtext CHARACTER SET utf8 NOT NULL,
  `year` longtext CHARACTER SET utf8 NOT NULL,
  `talimi_saal` int(11) NOT NULL,
  `page_num` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('1', '1', '1', '2019-01-23', 'علی', '40000', '1', '1440-05-16', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('2', '2', '2', '2019-01-23', 'علی', '1500', '1', '1440-05-16', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('3', '3', '4', '2019-01-24', 'علی', '5000', '1', '1440-05-17', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('4', '1', '67', '2019-01-24', 'امجد', '4000', '1', '1440-05-17', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('5', '4', '23', '2019-01-24', 'امجد', '6000', '1', '1440-05-17', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('6', '4', '33', '2019-01-24', 'علی', '6000', '1', '1440-05-17', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('7', '1', '22', '2019-01-24', 'علی', '4000', '1', '1440-05-17', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('8', '2', '44', '2019-01-24', 'امجد', '6000', '1', '1440-05-17', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('9', '3', '11', '2019-01-24', 'علی', '4000', '1', '1440-05-17', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('10', '4', '5', '2019-01-24', 'علی', '3000', '1', '1440-05-17', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('11', '1', '10', '2019-01-24', 'زمان خان', '4000', '1', '1440-05-17', '', '1439-1440', '27', '3');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('12', '2', '21', '2019-01-24', 'زمان خان', '7000', '1', '1440-05-17', '', '1439-1440', '27', '3');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('13', '3', '77', '2019-01-24', 'زمان خان', '9000', '1', '1440-05-17', '', '1439-1440', '27', '3');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('14', '4', '77', '2019-01-24', 'زمان خان', '8000', '1', '1440-05-17', '', '1439-1440', '27', '3');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('15', '3', '43424', '2019-01-27', 'علی', '100000000', '1', '1440-05-20', '', '1439-1440', '27', '3');


#
# TABLE STRUCTURE FOR: income_category
#

DROP TABLE IF EXISTS `income_category`;

CREATE TABLE `income_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf8 NOT NULL,
  `comment` longtext CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `income_category` (`id`, `name`, `comment`) VALUES ('1', 'صدقات واجبہ', '');
INSERT INTO `income_category` (`id`, `name`, `comment`) VALUES ('2', 'عطیات', '');
INSERT INTO `income_category` (`id`, `name`, `comment`) VALUES ('3', 'وصولی ماہانہ اخراجات', '');
INSERT INTO `income_category` (`id`, `name`, `comment`) VALUES ('4', 'العصر', '');


#
# TABLE STRUCTURE FOR: income_page_lock
#

DROP TABLE IF EXISTS `income_page_lock`;

CREATE TABLE `income_page_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `year` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `income_page_lock` (`id`, `number`, `status`, `year`) VALUES ('1', '1', '0', '1439-1440');
INSERT INTO `income_page_lock` (`id`, `number`, `status`, `year`) VALUES ('2', '2', '0', '1439-1440');
INSERT INTO `income_page_lock` (`id`, `number`, `status`, `year`) VALUES ('3', '3', '1', '1439-1440');


#
# TABLE STRUCTURE FOR: jamia_expenses
#

DROP TABLE IF EXISTS `jamia_expenses`;

CREATE TABLE `jamia_expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_category_id` int(11) NOT NULL,
  `child_expense_id` int(11) NOT NULL,
  `sub_child_expense_id` int(11) NOT NULL,
  `bill_no` int(11) NOT NULL,
  `date` date NOT NULL,
  `amount` int(11) NOT NULL,
  `arabic_month` int(11) NOT NULL,
  `arabic_date` date NOT NULL,
  `comment` longtext CHARACTER SET utf8,
  `year` longtext CHARACTER SET utf8 NOT NULL,
  `talimi_saal` int(11) NOT NULL,
  `page_num` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `child_expense_id` (`child_expense_id`),
  KEY `sub_child_expense_id` (`sub_child_expense_id`),
  KEY `arabic_month` (`arabic_month`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('1', '1', '1', '1', '21', '2019-01-13', '500', '5', '0000-00-00', '', '1439-1440', '27', '1');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('3', '1', '2', '2', '21', '2019-01-13', '500', '5', '0000-00-00', '', '1439-1440', '27', '1');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('4', '2', '13', '3', '34', '2019-01-14', '600', '5', '0000-00-00', '', '1439-1440', '27', '1');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('5', '1', '3', '5', '56', '2019-01-14', '7000', '5', '0000-00-00', '', '1439-1440', '27', '1');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('6', '1', '6', '6', '44', '2019-01-14', '600', '5', '0000-00-00', '', '1439-1440', '27', '1');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('7', '3', '16', '7', '33', '2019-01-14', '50000', '5', '0000-00-00', '', '1439-1440', '27', '1');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('8', '1', '9', '4', '33', '2019-01-14', '5000', '5', '0000-00-00', '', '1439-1440', '27', '1');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('9', '1', '2', '2', '11', '2019-01-14', '33', '5', '1440-05-07', '', '1439-1440', '27', '1');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('10', '1', '1', '1', '23', '2019-01-15', '400', '5', '1440-05-08', '', '1439-1440', '27', '1');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('11', '1', '1', '1', '99', '2019-01-15', '100', '5', '1440-05-08', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('12', '1', '2', '2', '1', '2019-01-15', '100', '5', '1440-05-08', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('13', '2', '13', '3', '2', '2019-01-15', '1000', '5', '1440-05-08', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('14', '1', '9', '4', '3', '2019-01-15', '2000', '5', '1440-05-08', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('15', '1', '3', '5', '5', '2019-01-15', '5000', '5', '1440-05-08', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('16', '3', '16', '7', '7', '2019-01-15', '10000', '5', '1440-05-08', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('17', '1', '1', '1', '23', '2019-01-15', '500', '5', '1440-05-08', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('18', '1', '2', '2', '78', '2019-01-15', '600', '5', '1440-05-08', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('19', '3', '16', '7', '88', '2019-01-16', '1000', '5', '1440-05-09', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('20', '3', '16', '7', '43245', '2019-01-16', '100000000', '5', '1440-05-09', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('21', '1', '3', '5', '45678', '2019-01-16', '100000000', '5', '1440-05-09', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('22', '1', '1', '1', '23', '2019-01-27', '7000', '5', '1440-05-20', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('23', '2', '13', '3', '56', '2019-01-27', '1000000', '5', '1440-05-20', '', '1439-1440', '27', '4');


#
# TABLE STRUCTURE FOR: language
#

DROP TABLE IF EXISTS `language`;

CREATE TABLE `language` (
  `phrase_id` int(11) NOT NULL AUTO_INCREMENT,
  `phrase` longtext COLLATE utf8_unicode_ci NOT NULL,
  `english` longtext COLLATE utf8_unicode_ci NOT NULL,
  `urdu` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`phrase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=568 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('1', 'class_routine', 'Class Routine', 'کلاس ضابط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('2', 'dashboard', 'Dashboard', 'ڈیش  بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('3', 'student', 'Student', 'طالب علم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('4', 'admit_student', 'Admit Student', ' داخلہ طالب علم ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('5', 'admit_bulk_student', 'Admit Bulk Student', 'بلک طالب علم کو داخل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('6', 'student_information', 'Student Information', 'طالب علم کی معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('7', 'class', 'Class', 'درجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('8', 'student_promotion', 'Student Promotion', 'طلبا کی پروموشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('9', 'teacher', 'Teacher', 'معلم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('10', 'parents', 'Parents', 'والدین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('11', 'manage_classes', 'Manage Classes', 'کلاسز انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('12', 'manage_sections', 'Manage Sections', 'حصے انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('13', 'subject', 'Subject', 'مضمون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('14', 'daily_attendance', 'Daily Attendance', 'روزان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('15', 'exam', 'Exam', 'امتحان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('16', 'exam_list', 'Exam List', 'امتحان فہرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('17', 'exam_grades', 'Exam Grades', 'امتحان گریڈز');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('18', 'manage_marks', 'Manage Marks', 'ترتیب نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('19', 'send_marks_by_sms', 'Send Marks By Sms', 'SMS کے ذریعے مارکس کا حساب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('20', 'tabulation_sheet', 'Tabulation Sheet', 'نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('21', 'accounting', 'Accounting', 'اکاونٹنگ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('22', 'create_student_payment', 'Create Student Payment', 'Student کی ادائیگی بنائیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('23', 'student_payments', 'Student Payments', 'Student کی ادائیگیاں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('24', 'expense', 'Expense', 'خرچ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('25', 'expense_category', 'Expense Category', 'اخراجات زمر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('26', 'library', 'Library', 'لائبریری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('27', 'transport', 'Transport', 'ٹرانسپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('28', 'dormitory', 'Dormitory', 'شیناگار');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('29', 'noticeboard', 'Noticeboard', 'نوٹس بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('30', 'message', 'Message', 'پیغام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('31', 'settings', 'Settings', 'ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('32', 'general_settings', 'General Settings', 'عام ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('33', 'sms_settings', 'Sms Settings', 'SMS کی ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('34', 'language_settings', 'Language Settings', 'زبان کی ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('35', 'account', 'Account', 'اکاؤنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('36', 'running_session', 'Running Session', 'سیشن چلانے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('37', 'edit_profile', 'Edit Profile', ' پروفائل ترمیم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('38', 'change_password', 'Change Password', 'پاس ورڈ تبدیل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('39', 'add_class_routine', 'Add Class Routine', 'کلاس معمول کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('40', 'section', 'Section', 'سیکشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('41', 'edit', 'Edit', 'تصیح');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('42', 'delete', 'Delete', 'حذف کرنا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('43', 'cancel', 'Cancel', 'منسوخ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('44', 'admin_dashboard', 'Admin Dashboard', 'ایڈمن ڈیش بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('45', 'event_schedule', 'Event Schedule', 'ایونٹ کے شیڈول');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('46', 'parent', 'Parent', 'ولدیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('47', 'attendance', 'Attendance', 'حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('48', 'add_student', 'Add Student', 'طالب علم کے لئے شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('49', 'addmission_form', 'Addmission Form', 'Addmission Form');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('50', 'name', 'Name', 'نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('51', 'value_required', 'Value Required', 'ویلیو مطلوب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('52', 'select', 'Select', 'منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('53', 'select_class_first', 'Select Class First', 'پہلے کلاس منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('54', 'roll', 'Serial  #', 'رول نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('55', 'birthday', 'DOB', 'سالگر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('56', 'gender', 'Gender', 'صنف');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('57', 'male', 'Male', 'مرد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('58', 'female', 'Female', 'خاتون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('59', 'address', 'Address', 'ایڈریس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('60', 'phone', 'Phone', 'موبائل نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('61', 'email', 'Email', 'ای میل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('62', 'password', 'Password', 'پاس ورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('63', 'transport_route', 'Transport Route', 'ٹرانسپورٹ روٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('64', 'photo', 'Photo', 'تصویر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('65', 'add_bulk_student', 'Add Bulk Student', 'بلک طالب علم ان کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('66', 'select_class', 'Select Class', 'کلاس منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('67', 'add_more_students', 'Add More Students', 'زیاد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('68', 'save_students', 'Save Students', 'طالب علموں کو مح');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('69', 'select_section', 'Select Section', 'سیکشن منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('70', 'add_new_student', 'Add New Student', 'نیا طالب علم  شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('71', 'all_students', 'All Students', 'تمام طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('72', 'options', 'Options', 'اختیارات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('73', 'mark_sheet', 'Mark Sheet', 'مارک شیٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('74', 'profile', 'Profile', ' پروفائل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('75', 'edit_student', 'Edit Student', 'Student کی تصیح');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('76', 'current_session', 'Current Session', 'موجود');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('77', 'promote_to_session', 'Promote To Session', 'اجلاس سے ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('78', 'promotion_from_class', 'Promotion From Class', 'کلاس سے پروموشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('79', 'promotion_to_class', 'Promotion To Class', 'کلاس میں پروموشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('80', 'select_all', 'Select All', 'تمام منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('81', 'select_none', 'Select None', 'کوئی بھی منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('82', 'average', 'Average', 'اوسط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('83', 'promote_slelected_students', 'Promote Slelected Students', 'منتخب طلبا کی پروموشن کریں ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('84', 'manage_teacher', 'Manage Teacher', 'ٹیچر انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('85', 'add_new_teacher', 'Add New Teacher', 'نیو ٹیچر شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('86', 'add_teacher', 'Add Teacher', 'استاد ان کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('87', 'edit_teacher', 'Edit Teacher', 'ٹیچر ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('88', 'sex', 'Sex', 'جنس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('89', 'marksheet_for', 'Marksheet For', 'Marksheet For');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('90', 'total_marks', 'Total Marks', 'مجموعی نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('91', 'average_grade_point', 'Average Grade Point', 'اوسط گریڈ پوائنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('92', 'print_marksheet', 'Print Marksheet', 'Print Marksheet');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('93', 'student_marksheet', 'Student Marksheet', 'طلباء ڈی ایم سی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('94', 'parent_phone', 'Parent Phone', 'والدین ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('95', 'all_parents', 'All Parents', 'تمام والدین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('96', 'add_new_parent', 'Add New Parent', 'نئے والدین کے لئے شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('97', 'profession', 'Profession', 'پیشہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('98', 'add_parent', 'Add Parent', 'داخلہ ولدیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('99', 'update', 'Update', 'اپ ڈیٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('100', 'manage_class', 'Manage Class', 'کلاس انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('101', 'class_list', 'Class List', 'کلاس کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('102', 'add_class', 'Add Class', 'کلاس شامل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('103', 'class_name', 'Class Name', 'کلاس نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('104', 'numeric_name', 'Numeric Name', 'نمبری نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('105', 'name_numeric', 'Name Numeric', 'نام نمبری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('106', 'select_teacher', 'Select Teacher', 'ٹیچر منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('107', 'edit_class', 'Edit Class', 'تصیح کلاس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('108', 'add_new_section', 'Add New Section', 'نیا سیکشن میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('109', 'section_name', 'Section Name', 'حصے کا نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('110', 'nick_name', 'Nick Name', 'نک نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('111', 'add_section', 'Add Section', 'سیکشن کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('112', 'manage_subject', 'Manage Subject', ' انتظام مضمون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('113', 'subject_list', 'Subject List', 'مضمون لسٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('114', 'add_subject', 'Add Subject', 'اندراج مضمون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('115', 'subject_name', 'Subject Name', 'نام مضمون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('116', 'edit_subject', 'Edit Subject', 'مضمون میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('117', 'day', 'Day', 'ڈے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('118', 'starting_time', 'Starting Time', 'وقت پر شروع');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('119', 'hour', 'Hour', 'قیامت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('120', 'minutes', 'Minutes', 'منٹس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('121', 'ending_time', 'Ending Time', 'وقت ختم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('122', 'edit_class_routine', 'Edit Class Routine', 'تصیح کلاس ضابط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('123', 'select_subject', 'Select Subject', 'مضمون منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('124', 'manage_daily_attendance', 'Manage Daily Attendance', 'روزان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('125', 'select_date', 'Select Date', 'تاریخ منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('126', 'select_month', 'Select Month', 'م');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('127', 'select_year', 'Select Year', 'چھانٹیں کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('128', 'manage_attendance', 'Manage Attendance', 'حاضری انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('129', 'manage_exam', 'Manage Exam', 'امتحان انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('130', 'add_exam', 'Add Exam', 'امتحان میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('131', 'exam_name', 'Exam Name', 'امتحان نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('132', 'date', 'Date', 'تاریخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('133', 'comment', 'Comment', 'تبصرہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('134', 'edit_exam', 'Edit Exam', 'امتحان میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('135', 'manage_grade', 'Manage Grade', 'گریڈ انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('136', 'grade_list', 'Grade List', 'گریڈ کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('137', 'add_grade', 'Add Grade', 'گریڈ کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('138', 'grade_name', 'Grade Name', 'گریڈ نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('139', 'grade_point', 'Grade Point', 'گریڈ نقط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('140', 'mark_from', 'Mark From', 'سے Mark');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('141', 'mark_upto', 'Mark Upto', 'مارک تک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('142', 'manage_exam_marks', 'Manage Exam Marks', 'امتحان مارکس کو منظم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('143', 'select_exam', 'Select Exam', 'امتحان منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('144', 'send_marks', 'Send Marks', 'مارکس کا حساب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('145', 'select_receiver', 'Select Receiver', 'وصول کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('146', 'students', 'Students', 'طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('147', 'select_a_class', 'Select A Class', 'A کلاس منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('148', 'select_an_exam', 'Select An Exam', 'ایک امتحان کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('149', 'view_tabulation_sheet', 'View Tabulation Sheet', 'ٹیبیولیشن شیٹ لنک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('150', 'subjects', 'Subjects', 'مضامین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('151', 'total', 'Total', 'کل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('152', 'create_single_invoice', 'Create Single Invoice', 'سنگل انوائس بنائیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('153', 'create_mass_invoice', 'Create Mass Invoice', 'ماس انوائس بنائیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('154', 'invoice_informations', 'Invoice Informations', 'انوائس کی معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('155', 'title', 'Title', 'عنوان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('156', 'description', 'Description', 'تفصیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('157', 'payment_informations', 'Payment Informations', 'ادائیگی کی معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('158', 'enter_total_amount', 'Enter Total Amount', 'کل رقم درج');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('159', 'payment', 'Payment', 'ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('160', 'enter_payment_amount', 'Enter Payment Amount', 'ادائیگی کی رقم درج');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('161', 'status', 'Status', 'سٹیٹس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('162', 'paid', 'Paid', 'ادا کی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('163', 'unpaid', 'Unpaid', 'بلا معاوض');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('164', 'method', 'Method', 'طریق');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('165', 'cash', 'Cash', 'نقد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('166', 'check', 'Check', 'چیک کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('167', 'card', 'Card', 'کارڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('168', 'add_invoice', 'Add Invoice', 'انوائس میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('169', 'unpaid_invoices', 'Unpaid Invoices', 'بلا معاوض');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('170', 'payment_history', 'Payment History', 'ادائیگی کی تاریخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('171', 'amount', 'Amount', 'رقم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('172', 'expenses', 'Expenses', 'اخراجات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('173', 'add_new_expense', 'Add New Expense', 'نئے اخراجات کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('174', 'category', 'Category', 'قسم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('175', 'add_expense', 'Add Expense', 'اخراجات میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('176', 'select_expense_category', 'Select Expense Category', 'منتخب اخراجات زمر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('177', 'add_new_expense_category', 'Add New Expense Category', 'شامل کریں نئے اخراجات زمر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('178', 'add_expense_category', 'Add Expense Category', 'اخراجات زمر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('179', 'edit_expense', 'Edit Expense', 'اخراجات میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('180', 'manage_library_books', 'Manage Library Books', 'کتب خانے کی کتابیں انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('181', 'book_list', 'Book List', 'کتاب کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('182', 'add_book', 'Add Book', 'کتاب شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('183', 'book_name', 'Book Name', 'کتاب کا نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('184', 'author', 'Author', 'مصن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('185', 'price', 'Price', 'قیمت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('186', 'available', 'Available', 'دستیاب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('187', 'unavailable', 'Unavailable', 'دستیاب ن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('188', 'manage_transport', 'Manage Transport', 'ٹرانسپورٹ کا انتظام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('189', 'transport_list', 'Transport List', 'ٹرانسپورٹ کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('190', 'add_transport', 'Add Transport', 'ٹرانسپورٹ شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('191', 'route_name', 'Route Name', 'روٹ نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('192', 'number_of_vehicle', 'Number Of Vehicle', 'گاڑی کا نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('193', 'route_fare', 'Route Fare', 'روٹ کرای');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('194', 'edit_transport', 'Edit Transport', 'ٹرانسپورٹ میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('195', 'manage_dormitory', 'Manage Dormitory', 'شیناگار انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('196', 'dormitory_list', 'Dormitory List', 'شیناگار کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('197', 'add_dormitory', 'Add Dormitory', 'شیناگار میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('198', 'dormitory_name', 'Dormitory Name', 'شیناگار نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('199', 'number_of_room', 'Number Of Room', 'کمر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('200', 'edit_dormitory', 'Edit Dormitory', 'شیناگار میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('201', 'manage_noticeboard', 'Manage Noticeboard', 'نوٹس بورڈ انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('202', 'noticeboard_list', 'Noticeboard List', 'نوٹس کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('203', 'add_noticeboard', 'Add Noticeboard', 'نوٹس بورڈ میں شامل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('204', 'notice', 'Notice', 'نوٹس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('205', 'add_notice', 'Add Notice', 'نوٹس کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('206', 'send_sms_to_all', 'Send Sms To All', 'سب پر SMS بھیجیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('207', 'yes', 'Yes', 'جی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('208', 'no', 'No', 'ن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('209', 'sms_service_not_activated', 'Sms Service Not Activated', 'ایس ایم ایس سروس چالو ن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('210', 'private_messaging', 'Private Messaging', 'ذاتی پیغام رسانی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('211', 'messages', 'Messages', 'پیغامات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('212', 'new_message', 'New Message', 'نیا پیغام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('213', 'write_new_message', 'Write New Message', 'نیا پیغام لکھیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('214', 'recipient', 'Recipient', 'وصول کنند');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('215', 'select_a_user', 'Select A User', 'A یوزر کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('216', 'write_your_message', 'Write Your Message', 'اپنا پیغام لکھیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('217', 'send', 'Send', 'حساب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('218', 'system_settings', 'System Settings', 'نظام کی ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('219', 'system_name', 'System Name', 'سسٹم کا نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('220', 'system_title', 'System Title', 'سسٹم کی سرخی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('221', 'paypal_email', 'Paypal Email', 'پے پال ای میل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('222', 'currency', 'Currency', 'کرنسی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('223', 'system_email', 'System Email', 'سسٹم کی ای میل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('224', 'select_running_session', 'Select Running Session', 'سیشن چلانے کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('225', 'language', 'Language', 'زبان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('226', 'text_align', 'Text Align', 'متن سیدھ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('227', 'save', 'Save', 'محفوظ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('228', 'update_product', 'Update Product', 'اپ ڈیٹ کی مصنوعات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('229', 'file', 'File', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('230', 'install_update', 'Install Update', 'اپ ڈیٹ کو انسٹال');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('231', 'theme_settings', 'Theme Settings', 'تھیم ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('232', 'default', 'Default', 'پ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('233', 'select_theme', 'Select Theme', 'تھیم منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('234', 'select_a_theme_to_make_changes', 'Select A Theme To Make Changes', 'تبدیلیاں کرنے کے لئے ایک تھیم منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('235', 'upload_logo', 'Upload Logo', 'اپ لوڈ کی علامت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('236', 'upload', 'Upload', 'اپ لوڈ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('237', 'select_a_service', 'Select A Service', 'ایک خدمت کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('238', 'not_selected', 'Not Selected', 'منتخب ن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('239', 'disabled', 'Disabled', 'معذور');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('240', 'clickatell_username', 'Clickatell Username', 'Clickatell رکنیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('241', 'clickatell_password', 'Clickatell Password', 'Clickatell پاس ورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('242', 'clickatell_api_id', 'Clickatell Api Id', 'Clickatell API ID');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('243', 'twilio_account', 'Twilio Account', 'Twilio اکاؤنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('244', 'authentication_token', 'Authentication Token', 'توثیق ٹوکن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('245', 'registered_phone_number', 'Registered Phone Number', 'رجسٹرڈ ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('246', 'manage_language', 'Manage Language', 'زبان انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('247', 'language_list', 'Language List', 'زبان کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('248', 'add_phrase', 'Add Phrase', 'جمل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('249', 'add_language', 'Add Language', 'زبان کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('250', 'option', 'Option', 'آپشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('251', 'edit_phrase', 'Edit Phrase', 'جمل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('252', 'delete_language', 'Delete Language', 'زبان چھپانا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('253', 'phrase', 'Phrase', 'جمل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('254', 'manage_profile', 'Manage Profile', 'پروفائل کا نظم ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('255', 'update_profile', 'Update Profile', 'اپ ڈیٹ پروفائل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('256', 'current_password', 'Current Password', 'موجودہ پاس ورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('257', 'new_password', 'New Password', 'نیا پاس ورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('258', 'confirm_new_password', 'Confirm New Password', 'نئے پاس ورڈ کی توثیق کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('259', 'login', 'Login', 'لاگ ان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('260', 'forgot_your_password', 'Forgot Your Password', 'پاس ورڈ بھول گیا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('261', 'reset_password', 'Reset Password', 'پاس ورڈ ری سیٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('262', 'return_to_login_page', 'Return To Login Page', 'پیج لاگ ان واپس جائیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('263', 'service_is_disabled', 'Service Is Disabled', 'سروس غیر ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('264', 'promote_to_selected_class', 'Promote To Selected Class', 'منتخب شد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('265', 'stay_in_present_class', 'Stay In Present Class', 'موجود');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('266', 'data_updated', 'Data Updated', 'ڈیٹا کو اپ ڈیٹ.');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('267', 'data_added_successfully', 'Data Added Successfully', 'معلومات کو کامیابی سے شامل کر د یے گیے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('268', 'edit_grade', 'Edit Grade', 'گریڈ میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('269', 'manage_attendance_of_class', 'Manage Attendance Of Class', 'کلاس کی حاضری انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('270', 'present', 'Present', 'حاضر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('271', 'absent', 'Absent', 'غائب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('272', 'update_attendance', 'Update Attendance', 'اپ ڈیٹ حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('273', 'undefined', 'Undefined', 'مبہم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('274', 'back', 'Back', 'واپس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('275', 'save_changes', 'Save Changes', 'تبدیلیاں محفوظ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('276', 'data_deleted', 'Data Deleted', 'ڈیٹا حذف کردیا گیا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('277', 'academic_syllabus', 'Academic Syllabus', 'تعلیمی نصاب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('278', 'add_academic_syllabus', 'Add Academic Syllabus', 'تعلیمی نصاب میں شامل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('279', 'uploader', 'Uploader', 'اپ لوڈر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('280', 'upload_academic_syllabus', 'Upload Academic Syllabus', 'اپ لوڈ کریں تعلیمی نصاب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('281', 'upload_syllabus', 'Upload Syllabus', 'اپ لوڈ کریں نصاب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('282', 'syllabus_uploaded', 'Syllabus Uploaded', 'نصاب اپ لوڈ کرد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('283', 'download', 'Download', 'لوڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('284', 'remove', 'Remove', 'دور');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('285', 'print', 'Print', 'پرنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('286', 'teacher_dashboard', 'Teacher Dashboard', 'ٹیچر ڈیش بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('287', 'study_material', 'Study Material', 'تربیتی مواد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('288', 'teacher_list', 'Teacher List', 'ٹیچر لسٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('289', 'manage_class_routine', 'Manage Class Routine', 'کلاس ضابط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('290', 'class_routine_list', 'Class Routine List', 'کلاس معمول کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('291', 'add_study_material', 'Add Study Material', 'تربیتی مواد شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('292', 'file_type', 'File Type', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('293', 'select_file_type', 'Select File Type', 'منتخب ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('294', 'image', 'Image', 'تصویر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('295', 'doc', 'Doc', 'ڈاکٹر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('296', 'pdf', 'Pdf', 'پی ڈی ای');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('297', 'excel', 'Excel', 'ایکسل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('298', 'other', 'Other', 'دیگر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('299', 'manage_promotion', 'Manage Promotion', 'پروموشن کا نظم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('300', 'select_class_for_promotion_to_and_from', 'Select Class For Promotion To And From', 'اور سے پروموشن کے لئے کلاس کو منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('301', 'students_of_class', 'Students Of Class', 'کلاس کے طالب علموں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('302', 'enroll_to_class', 'Enroll To Class', 'کلاس اندراج کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('303', 'add_a_row', 'Add A Row', 'ایک قطار میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('304', 'marks_obtained', 'Marks Obtained', 'حاصل کردہ نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('305', 'marks_updated', 'Marks Updated', 'مارکس تاز');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('306', 'marks_for', 'Marks For', 'کے لئے نشان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('307', 'attendance_for_class', 'Attendance For Class', 'کلاس کے لئے حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('308', 'print_tabulation_sheet', 'Print Tabulation Sheet', 'پرنٹ ٹیبیولیشن شیٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('309', 'receiver', 'Receiver', 'وصول');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('310', 'please_select_receiver', 'Please Select Receiver', 'وصول برا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('311', 'session_changed', 'Session Changed', 'سیشن تبدیل کر دیا گیا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('312', 'attendance_updated', 'Attendance Updated', 'حاضری تاز');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('313', 'study_material_info_saved_successfuly', 'Study Material Info Saved Successfuly', 'تربیتی مواد ان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('314', 'edit_study_material', 'Edit Study Material', 'تصیح تربیتی مواد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('315', 'parent_dashboard', 'Parent Dashboard', 'والدین کا ڈیش بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('316', 'exam_marks', 'Exam Marks', 'امتحان مارکس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('317', 'total_mark', 'Total Mark', 'کل مارک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('318', 'mark_obtained', 'Mark Obtained', 'حاصل کردہ نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('319', 'manage_invoice/payment', 'Manage Invoice/payment', 'انتظام کریں انوائس / ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('320', 'invoice/payment_list', 'Invoice/payment List', 'انوائس / ادائیگی کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('321', 'student_dashboard', 'Student Dashboard', 'طالب علم کا ڈیش بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('322', 'obtained_marks', 'Obtained Marks', 'حاصل کردہ نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('323', 'highest_mark', 'Highest Mark', 'سب سے زیاد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('324', 'grade', 'Grade', 'تقدیر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('325', 'take_payment', 'Take Payment', 'ادائیگی کے لے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('326', 'view_invoice', 'View Invoice', 'لنک انوائس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('327', 'creation_date', 'Creation Date', 'بنانے کی تاریخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('328', 'payment_to', 'Payment To', 'کرنے کے لئے ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('329', 'bill_to', 'Bill To', 'کا بل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('330', 'total_amount', 'Total Amount', 'مجموعی رقم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('331', 'paid_amount', 'Paid Amount', 'ادا کی گئی رقم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('332', 'due', 'Due', 'وج');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('333', 'amount_paid', 'Amount Paid', 'رقم ادا کر دی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('334', 'payment_successfull', 'Payment Successfull', 'ادائیگی کامیاب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('335', 'add_invoice/payment', 'Add Invoice/payment', 'شامل کریں انوائس / ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('336', 'invoices', 'Invoices', 'انوائس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('337', 'action', 'Action', 'عمل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('338', 'required', 'Required', 'مطلوب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('339', 'info', 'Info', 'معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('340', 'view_academic_performance', 'View Academic Performance', 'تعلیمی کارکردگی دیکھیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('341', 'phrase_list', 'Phrase List', 'جمل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('342', 'update_phrase', 'Update Phrase', 'اپ ڈیٹ کے جملے سے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('343', 'edit_invoice', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('344', 'students_added', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('345', 'student_already_enrolled', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('346', 'new_enrollment_successfull', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('347', 'reply_message', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('348', 'dob_in_words', 'DOB in Words', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('349', 'caste', 'Caste or Tribe', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('350', 'admission_date', 'Admission Date', ' داخلہ تاریخ  ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('351', 'status_first', '1st Mtg', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('352', 'status_last', '2nd Mtg', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('353', 'prev_atd', 'Prev Attd', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('354', 'curr_atd', 'Curr Attd', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('355', 'total_atd', 'TotalAttd', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('356', 'fines', 'Fines', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('357', 'remarks', 'Remarks', 'کیفیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('359', 'current_address', '', 'موجودہ پتہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('360', 'permanent_address', '', 'مستقل پتہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('361', 'religion', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('362', 'muslim', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('363', 'non_muslim', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('364', 'nic', 'NIC', 'شناختی کارڈ نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('365', 'blood_group', '', 'بلڈ گروپ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('366', 'entry_test_marks', '', 'امتحان داخلہ نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('367', 'designation', '', 'نامزد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('368', 'student_wise', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('369', 'total_income', '', 'مجموعی امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('370', 'logout', '', 'چھوڑنا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('371', 'total_male_students', '', 'تمام طلبہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('372', 'total_female_students', '', 'تمام طالبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('373', 'countries', '', 'مما لک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('374', 'manage_countries', '', 'انتظام مما لک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('375', 'country_details', '', 'تفصیل ممالک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('376', 'add_country', '', 'ملک شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('377', 'serial_no', '', 'نمبر شمار');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('378', 'country', '', 'ملک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('379', 'data_updated_successfully', '', 'معلومات کو کامیابی سے اپ ڈیٹ کر د یا گیا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('380', 'add_province', '', 'صوبہ شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('381', 'province', '', 'صوبہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('382', 'province_details', '', 'صوبے کی تفصیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('383', 'select_country', '', 'ملک کا انتخاب کیجئے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('384', 'edit_province', '', 'صوبے کی ترمیم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('385', 'districts', '', 'اضلاع');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('386', 'manage_districts', '', 'انتظام اضلاع');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('387', 'district_details', '', 'تفصیل اضلاع');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('388', 'add_district', '', 'ضلع  شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('389', 'select_province', '', 'صوبہ منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('390', 'district_name', '', 'ضلع کا نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('391', 'select_country_first', '', 'پہلا ملک منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('392', 'district', '', 'ضلع');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('393', 'branch', '', 'شاخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('394', 'select_branch', '', 'شاخ منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('395', 'manage_section', '', 'سیکشن  انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('396', 'submit', '', 'داخل کرنا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('397', 'personal_info', '', 'ذاتی معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('398', 'address_info', '', 'معلومات رہائش');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('399', 'reg_no', '', 'رجسٹریشن نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('400', 'dob', '', 'تاریخ پیدائش');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('401', 'admit_class', 'Admit Class', 'مطلوبہ درجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('402', 'class_roll', '', 'درجہ رول نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('403', 'select_image', 'Select Image', 'تصویر منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('404', 'next', '', 'اگلے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('405', 'previous', '', 'پچھلا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('406', 'select_province_first', '', 'پہلے صوبہ منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('407', 'last_class_attended', '', ' آخری پاس کردہ درجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('408', 'school_name', '', 'نام مدرسہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('409', 'parent_data', '', ' معلومات والدین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('410', 'class_number', '', 'کلاس نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('411', 'edit_form', '', 'فارم تصیح');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('412', 'withdraw', '', 'خارج کرنا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('413', 'remark', 'Remarks', 'رمارکس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('414', 'checked_by', '', 'چیک باٰیٰ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('415', 'prepared_by', '', 'تیارکرنےوالا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('416', 'reason', '', 'وجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('417', 'withdraw_date', '', 'تاریخ خارج');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('418', 'withdraw_student', '', 'خارج طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('419', 'users', 'Users', 'صارفین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('420', 'user', 'User', 'صارف');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('421', 'add_user', 'Add User', 'صارف شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('422', 'user_type', '', 'صارف کی قسم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('423', 'admin', '', 'ایڈمن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('424', 'accountant', '', 'اکاؤنٹنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('425', 'examiner', '', 'جائزہ کار');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('426', 'librarian', '', 'لائبریرین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('427', 'select_user', 'Select User', 'صارف کا انتخاب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('428', 'system_users', 'System Users', 'صارفین نظام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('429', 'main_branch', 'Main Branch', 'مرکزی شاخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('430', 'select_branch_first', 'Select Branch First', 'پھلے شاخ منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('431', 'new_students', 'New Students', 'جدید طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('432', 'old_students', 'Old Students', 'قدیم طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('433', 'marks', 'Marks', 'نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('434', 'session', 'Session', 'سیشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('435', 'admit_student_through_excel', 'admit student through excel ', 'داخلہ طلباء بذریعہ ایکسل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('436', 'select_excel_file', '', ' منتخب ایکسل فایل ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('437', 'exams', '', 'امتحانات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('438', 'talimi_saal', 'Educational Year', 'تعلیمی سال');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('439', 'staff', '', 'خادمین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('440', 'staff_managment', '', 'ترتیبات خادمین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('441', 'contract_type', '', 'قسم معاہدہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('443', 'employee_type', '', 'اقسام خادم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('444', 'employee_type_list', '', 'فہرست اقسام خادمین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('445', 'add_new_employee', '', 'نیاءخادم شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('446', 'type', '', 'قسم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('447', 'edit_employee_type', '', 'تصیح اقسام خادم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('448', 'contract', '', 'کنٹریکٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('449', '-select-', '', '-منتخب کریں-');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('450', 'joining_date', '', 'تاریخ شمولیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('451', 'social_links', '', 'سماجی روابط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('452', 'add_employee', '', 'خادم کو داخل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('453', 'edit_employee', '', 'تصیح خادم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('454', 'print_data_detail', '', 'تفصیلات پرنٹ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('455', 'edit_image', '', 'تصویر تبدیل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('456', 'student_report', '', 'طلباء رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('457', 'exam_roll', '', 'امتحانی رول نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('458', 'student_exam_roll', '', 'طلباء امتحانی نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('459', 'exam_roll_report', '', 'امتحانی نمبر رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('460', 'create', '', ' بنائے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('461', 'student_exam_roll_record', '', 'فہرست رول نمبربرائے جائزات وامتحانات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('462', 'signature', '', 'دستخط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('463', 'error_message', '', 'پیغام غلطی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('464', 'student_card', '', 'طلباء کارڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('465', 'students_information', '', 'معلومات طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('466', 'single_tabulation_sheet', '', 'انفرادی نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('467', 'percentage', '', 'فیصد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('468', 'position', '', 'پوزیشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('469', 'fail', '', 'راسب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('470', 'exam_attendance', '', 'امتحانی حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('471', 'class_attendance', '', 'درجہ حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('472', 'result', '', 'نتیجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('473', 'sign_educator', '', 'امین ادارة التعلیم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('474', 'single_marksheet', 'Single Marksheet', 'انفرادی ڈی ایم سی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('475', 'marksheet', 'Marksheet', 'نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('476', 'class_position', '', 'کلاس پوزیشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('477', 'highest_marks', '', 'سب سے ذیادہ نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('478', 'combine_tabulation_sheet', '', 'اجتماعی نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('479', 'combine_marksheet', '', 'اجتماعی ڈی ایم سی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('480', 'annual_marksheet', '', 'سالا نہ ڈی ایم سی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('481', 'results', '', 'نتائیج');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('482', 'single_result', '', 'انفرادی نتیجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('483', 'multiple_result', '', 'اجتماعی نتیجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('484', 'award_list', '', 'نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('485', 'award_list_single', '', 'انفرادی نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('486', 'award_list_multiple', '', 'اجتماعی نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('487', 'form_hifz_ahadees', '', 'فارم برائے حفظ احادیث');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('488', 'subject_attendance', '', 'حاضری مضامین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('489', 'subject_attendance_report', '', 'رپورٹ مضامین حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('490', 'show_report', '', 'رپورٹ دکھائیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('491', 'class_attendance_report', '', 'کلاس حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('492', 'month', '', 'مہینہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('493', 'takrar_attendance', '', ' تکرار حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('494', 'exam_report_form', '', 'فارم برائے شفوی امتحان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('495', 'takrar_attendance_report', '', 'تکرار حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('496', 'study_attendance', '', 'مطالعہ حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('497', 'study_attendance_report', '', 'مطالعہ حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('498', 'annual_attendance_report', '', 'سالانہ حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('499', 'monthly_attendance_report', '', 'ماہانہ حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('500', 'leave', '', 'رخصت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('501', 'friday_attendance', '', 'حاضری بروز جمعہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('502', 'friday_attendance_report', '', 'جمعہ حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('503', 'year', '', 'سال');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('504', 'annual_positions', '', 'سالانہ پوزیشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('505', 'mid_exam', '', 'چارنیم ماہی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('506', 'final_exam', '', 'سالانہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('507', 'form_inzibati_karwaie', '', 'انضباتی کارروائی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('508', 'student_search', '', 'تلاش طلبہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('509', 'card_expiration_date', '', 'کارڈ تاریخ تنسیخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('510', 'service_card', '', 'سروس کارڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('511', 'data_form', '', 'ڈیٹا فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('512', 'guardian', '', 'سرپرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('513', 'add_guardian', '', 'سرپرست داخل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('514', 'student_fee', '', 'طلبہ فیس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('515', 'student_fee_info', '', 'طلبہ فیس معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('516', 'monthly_fee', '', 'ماہانہ ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('517', 'Sponsor', '', 'کفیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('518', 'beneficiary', '', 'متکفل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('519', 'sponsor_list', '', 'کفیل فہرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('520', 'add_sponsor', '', 'داخلہ کفیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('521', 'student_transaction', '', 'طلبہ فیس ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('522', 'paid_payment', '', 'وصول شدہ رقم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('523', 'remaining', '', 'بقایا رقم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('524', 'student_list', '', 'طلبہ فہرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('525', 'edit_exam_roll_number', '', 'تصیح امتحانی نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('526', 'self_payment', '', 'ذاتی تعاون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('527', 'detail', '', 'تفصیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('528', 'fee_invoice', '', 'فیس رسید');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('529', 'transaction_list', '', 'ادائیگی فہرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('530', 'class_fee_record', '', 'کلاس فیس ریکارڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('531', 'monthly', '', 'ماہانہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('532', 'student_paid_fee_record', '', 'طلبہ اداشدہ فیس ریکارڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('533', 'beneficiary_report', '', 'کفالت رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('534', 'sponsor_name', '', 'نام کفیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('535', 'sponsor_monthly_help', '', 'زرکفالت ماہانہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('536', 'beneficiary_student_fee_report', '', 'کفالت شدہ طلبہ فیس رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('537', 'jamia_expenses', '', 'جامعہ اخراجات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('538', 'jamia_expenses_category', '', 'جامعہ اخراجات اقسام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('539', 'expnese_category_list', '', 'اقسام اخراجات فہرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('540', 'add_category', '', 'داخل اقسام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('541', 'expenses_category_print', '', 'گوشوارا پرنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('542', 'goshwara', '', 'گوشواراہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('543', 'empty_months_report', '', 'خالی ماہانہ رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('544', 'reports', '', 'رپورٹس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('545', 'total_class_fee_report', '', 'مجموعی کلاس فیس رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('546', 'branch_fee_report', '', 'شاخ فیس رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('547', 'expenses_category', '', 'اقسام اخراجات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('548', 'expneses_report', '', 'اخراجات رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('549', 'scholorship', '', 'وظیفہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('550', 'in_subject_of', '', 'بابت برائے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('551', 'jamia_expenses_report', '', 'جامعہ اخراجات رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('552', 'expenses_type', '', 'اقسام خرچ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('553', 'add_expense_type', '', 'شامل اقسام خرچ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('554', 'expenses_mad', '', 'مد اقسام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('555', 'add_expenses_mad', '', 'مد اقسام شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('556', 'khata_banam', '', 'کھاتہ بنام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('557', 'bill_no', '', 'بل نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('558', 'page_no', '', 'صفحہ نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('559', 'jamia_income', '', 'جامعہ امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('560', 'income_category', '', 'اقسام امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('561', 'add_income_type', '', 'اقسام امد شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('562', 'update_income_type', '', 'تصیح اقسام امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('563', 'add_income', '', 'امد شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('564', 'income', '', 'امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('565', 'income_type', '', 'اقسام امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('566', 'income_report', '', 'امد رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('567', 'assistant_name', '', 'نام معاون');


#
# TABLE STRUCTURE FOR: noticeboard
#

DROP TABLE IF EXISTS `noticeboard`;

CREATE TABLE `noticeboard` (
  `notice_id` int(11) NOT NULL AUTO_INCREMENT,
  `notice_title` longtext COLLATE utf8_unicode_ci NOT NULL,
  `notice` longtext COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `show_on_website` int(11) DEFAULT NULL,
  `image` longtext COLLATE utf8_unicode_ci,
  `create_timestamp` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: page_lock
#

DROP TABLE IF EXISTS `page_lock`;

CREATE TABLE `page_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `year` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('1', '1', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('4', '2', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('5', '3', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('6', '4', '1', '1439-1440');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`settings_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('1', 'system_name', 'جامعہ عثمانیہ پشاور');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('2', 'system_title', 'جامعہ عثمانیہ پشاور');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('3', 'address', 'Fabo Nawshehra Pakistan');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('4', 'phone', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('5', 'paypal_email', 'none');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('6', 'currency', 'money');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('7', 'system_email', 'imsunny37@gmail.com');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('11', 'language', 'urdu');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('12', 'text_align', 'right-to-left');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('13', 'clickatell_user', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('14', 'clickatell_password', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('15', 'clickatell_api_id', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('16', 'skin_colour', 'default');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('17', 'twilio_account_sid', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('18', 'twilio_auth_token', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('19', 'twilio_sender_phone_number', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('20', 'active_sms_service', 'disabled');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('21', 'running_year', '1439-1440');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('22', 'absent_message', ' آپکا بچہ آج غیر حاضر ہے۔');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('23', 'talimi_saal', '27');


#
# TABLE STRUCTURE FOR: sub_child_expense_category
#

DROP TABLE IF EXISTS `sub_child_expense_category`;

CREATE TABLE `sub_child_expense_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf8 NOT NULL,
  `child_expense_id` int(11) NOT NULL,
  `comment` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('1', 'برقی الات', '1', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('2', 'سوئی گیس', '2', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('3', 'ضیافت', '13', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('4', 'سٹیشنری', '9', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('5', 'مطبخ', '3', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('6', 'ٹیلیفون', '6', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('7', 'تعمیردار مالک', '16', '');


