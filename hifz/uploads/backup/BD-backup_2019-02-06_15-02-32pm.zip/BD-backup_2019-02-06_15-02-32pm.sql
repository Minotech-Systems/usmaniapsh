#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8_unicode_ci NOT NULL,
  `email` longtext COLLATE utf8_unicode_ci NOT NULL,
  `password` longtext COLLATE utf8_unicode_ci NOT NULL,
  `level` longtext COLLATE utf8_unicode_ci NOT NULL,
  `authentication_key` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `admin` (`admin_id`, `name`, `email`, `password`, `level`, `authentication_key`) VALUES ('1', 'اکاونٹنٹ', 'account', '8cb2237d0679ca88db6464eac60da96345513964', '1', '');


#
# TABLE STRUCTURE FOR: child_expense_category
#

DROP TABLE IF EXISTS `child_expense_category`;

CREATE TABLE `child_expense_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf8 NOT NULL,
  `expenses_category_id` int(11) NOT NULL,
  `comment` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('1', 'بجلی', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('2', 'گیس ایندھن', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('3', 'مطبخ', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('4', 'تنخواہ', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('5', 'خرچہ امتحانات', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('6', 'ٹیلیفون/فیکس', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('7', 'ڈاک', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('8', 'ٓامدورفت', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('9', 'سٹیشنری', '1', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('10', 'کتب', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('11', 'العصر', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('12', 'وظائف', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('13', 'ضیافت', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('14', 'تقریبات', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('15', 'متفرقات', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('16', 'تعمیرات', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('17', 'خریداری زمین', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('18', 'مرمت بلڈنگ', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('19', 'سنیٹری', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('20', 'دفتری ٓالات', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('21', 'برقی الات', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('22', 'فرنیچر', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('23', 'ڈسپنسری', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('24', 'العصر اکیڈمی', '2', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('25', 'اخبار', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('26', 'مرمت', '3', '');
INSERT INTO `child_expense_category` (`id`, `name`, `expenses_category_id`, `comment`) VALUES ('27', 'وفاق المدارس', '3', '');


#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01085b5d038bf12e0bc1ef707aa7be1f95bb7cc8', '::1', '1549292563', '__ci_last_regenerate|i:1549292379;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01676928409f3571c10cb26c103c98959fb4515a', '::1', '1549295739', '__ci_last_regenerate|i:1549295629;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('02647659c389722bf7c9aa3c6d098a821ebef001', '::1', '1548648154', '__ci_last_regenerate|i:1548647863;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('02a4b75350d1ff67e905a2f9a83e0696a639ff17', '::1', '1549202731', '__ci_last_regenerate|i:1549202572;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('03a7ca5c2fbbc8ff69056a6d263cfb8d40629763', '::1', '1549006404', '__ci_last_regenerate|i:1549006145;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('057d140fc1ef3dbb97174ef66eb084b73f5f462f', '::1', '1549266730', '__ci_last_regenerate|i:1549266453;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('057ee72ef81ae22f1660c31818ab471f1dc397a9', '::1', '1548826268', '__ci_last_regenerate|i:1548825979;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('065f9675c36cd30e7926d88eedc18eb511cd7b49', '::1', '1549291423', '__ci_last_regenerate|i:1549291287;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('07f001654e822d94379e159845b23605cb63c4ba', '::1', '1548820966', '__ci_last_regenerate|i:1548820966;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('09501134babf89ee46bca3ac4967630fcc93cead', '::1', '1549205689', '__ci_last_regenerate|i:1549205589;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('09b50d91c2ed5b3c5f56e196b13397661b69bf29', '::1', '1548824360', '__ci_last_regenerate|i:1548824086;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('09c44e069739b1f937ae5553a8ccc328aed3f539', '::1', '1548825865', '__ci_last_regenerate|i:1548825570;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0a4ea7ba1c5a76c8994ffdf8027a8467d5ce321c', '::1', '1549290827', '__ci_last_regenerate|i:1549290818;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0a741ccb29266a3527fbec685ed40f4d13a64c66', '::1', '1549204523', '__ci_last_regenerate|i:1549204272;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0b94fb6681568e8ebdb93b000dffb4639cf28c7d', '::1', '1549202529', '__ci_last_regenerate|i:1549202228;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f78bc6fb71ad44534c7d976723b2bc166a89e5d', '::1', '1549288507', '__ci_last_regenerate|i:1549288244;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:69:\"صفحہ کو کامیابی سے تبدیل کر دیا گیا۔۔۔\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('10231e20a5a76985a0a796f2d346673d7ba5f526', '::1', '1549365639', '__ci_last_regenerate|i:1549365363;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('10693316bed9d2f9b1204c16f1440297e160c552', '::1', '1549204676', '__ci_last_regenerate|i:1549204595;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('116e39e0306cc455e501cd605306db6e50789abd', '::1', '1549204578', '__ci_last_regenerate|i:1549204577;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('118c42abced35319b79f7671daf5804431916db2', '::1', '1549461400', '__ci_last_regenerate|i:1549461166;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1213a5c2ab677fea2f4fe39b4f41a269163992cb', '::1', '1548567099', '__ci_last_regenerate|i:1548566863;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('13090f6d8b7a5c29d35661384a60ad9c1727de3c', '::1', '1549179811', '__ci_last_regenerate|i:1549179775;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('132247f0fcb9e5441e33f105b892c7cd273a8601', '::1', '1548569913', '__ci_last_regenerate|i:1548569619;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('14fbfbe0124c240293502d3f04e1dae71f623a5f', '::1', '1548688366', '__ci_last_regenerate|i:1548688344;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('159adf2da28d8b33a8575cc06504258fa91771df', '::1', '1549291727', '__ci_last_regenerate|i:1549291440;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('181807a72409f794405d42450eb6fc15b30b0172', '::1', '1549287609', '__ci_last_regenerate|i:1549287594;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('18dc11c1f10ee6d4f2c5ffe6cf910264cb7b6266', '::1', '1548647240', '__ci_last_regenerate|i:1548647236;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1a7353f2e436f02d343a9b3a97b057153e370614', '::1', '1548649459', '__ci_last_regenerate|i:1548649452;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1acbe7298dcb977ce24b0614a67660c17c3e9d5b', '::1', '1548647123', '__ci_last_regenerate|i:1548646837;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1b6ed9bb06b4ac3ae445aaf5c63195bd55f630ca', '::1', '1549025093', '__ci_last_regenerate|i:1549024897;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:69:\"صفحہ کو کامیابی سے تبدیل کر دیا گیا۔۔۔\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1deb4116a45c26f02f2dcfa17179c9ee9683c325', '::1', '1549367238', '__ci_last_regenerate|i:1549367188;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1e0a82f3eee9ddc1c566dd70d9d2c052bfe1ca21', '::1', '1548677873', '__ci_last_regenerate|i:1548677870;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ea03108a62a33cd6b77b27ceb7a7ec2f47a37f5', '::1', '1549289317', '__ci_last_regenerate|i:1549289032;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ebad21a166c3f9228b3693d90d8070d4ed56fda', '::1', '1548570415', '__ci_last_regenerate|i:1548570128;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1f1f2870d38c13e450aee50be001e428c86010d4', '::1', '1548573057', '__ci_last_regenerate|i:1548572777;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('20115b77098d1318f4d3481d9cfd3c6796c0d37a', '::1', '1548687304', '__ci_last_regenerate|i:1548687246;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('20c994ca47ea844f42df07124d875cdffd02e28d', '::1', '1549205156', '__ci_last_regenerate|i:1549204889;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('220efa2712a0202d67da3af802bb5ee14d2e603b', '::1', '1548825175', '__ci_last_regenerate|i:1548824998;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('22639216a32576d771da3c1246572936e7d29df6', '::1', '1548674561', '__ci_last_regenerate|i:1548674293;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('237fed85e26a809f29b98a5f2d83072a16b57cb8', '::1', '1548670277', '__ci_last_regenerate|i:1548669930;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('254b848ebcbb4f6129e156ff8d9fc492ce9537bc', '::1', '1548671252', '__ci_last_regenerate|i:1548671024;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2749975b8e1bb84077e19790b94e6c8620ec80d3', '::1', '1548566694', '__ci_last_regenerate|i:1548566534;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('276e4273cc6bb3ca526f13be1868ea733f4c0505', '::1', '1549366017', '__ci_last_regenerate|i:1549366010;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('291b7ab1039dd7c0e03da260d49433e37fef8fc2', '::1', '1548571077', '__ci_last_regenerate|i:1548570790;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('29433f1cfa97670dda0f5921f81bf29f70e560e0', '::1', '1548695592', '__ci_last_regenerate|i:1548695575;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2abb1545848e44100ab587735dfc04c22e243a4a', '::1', '1549366201', '__ci_last_regenerate|i:1549366047;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2b5beb53886955f40d2f8690d1acc252b9706dd4', '::1', '1548669343', '__ci_last_regenerate|i:1548669343;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2b65fe957d9a9386fe378eb0f7115935b56a2164', '::1', '1549025275', '__ci_last_regenerate|i:1549025202;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2bd915785683f892d0365843096fe581075cf937', '::1', '1548693952', '__ci_last_regenerate|i:1548693702;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2d8af2a73a13a35d3328b0c6e1a58662f601b48e', '::1', '1549267212', '__ci_last_regenerate|i:1549267069;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3056696fce9b2458dc4aafc0a66cbae0d558e06c', '::1', '1549198094', '__ci_last_regenerate|i:1549197801;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('30c2d044d3ea05af3244ce8dcb6e38c28982f632', '::1', '1548646360', '__ci_last_regenerate|i:1548646145;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('31e7aa9e1c0381f7c8fff04d0ec11094b43543a1', '::1', '1549025927', '__ci_last_regenerate|i:1549025771;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:71:\"معلومات کو کامیابی سے اپ ڈیٹ کر د یا گیا\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3219ecf0b3ffc8d41fb268afb91a3f14cb3e3e45', '::1', '1548672536', '__ci_last_regenerate|i:1548672249;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('343e82aa51b483aa0a7db6b2846d6f9d31cf5bde', '::1', '1548821591', '__ci_last_regenerate|i:1548821299;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('345a3541c90146984bb069e12e0c96c0bed4da8f', '::1', '1548673222', '__ci_last_regenerate|i:1548672943;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('35e3f6b624b2cd4d7adfe7a1141d27de31b790aa', '::1', '1549024849', '__ci_last_regenerate|i:1549024645;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('35f29be631d73d1de83979f34cd7daecda7815b1', '::1', '1548570716', '__ci_last_regenerate|i:1548570472;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('37aa940f6b6a5808bd3148f9c83c80dba869c3f1', '::1', '1549290787', '__ci_last_regenerate|i:1549290675;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:71:\"معلومات کو کامیابی سے اپ ڈیٹ کر د یا گیا\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('39aed443c9a0ca45e2ce30461dc99bd851e85f8c', '::1', '1548574581', '__ci_last_regenerate|i:1548574573;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3b37b4392cc63b1e30dc62bb5eac222bc3539a55', '::1', '1548673762', '__ci_last_regenerate|i:1548673573;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3cfcd7aec8fb1482c8f1f46c4d145e5cd90b3eb6', '::1', '1549352848', '__ci_last_regenerate|i:1549352819;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3d08ddf564d3d88e04dcf2820228d6d2a1b41dff', '::1', '1548693362', '__ci_last_regenerate|i:1548693344;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3e3fefa32acdc53b2432769bb98db1ffab262e2c', '::1', '1548567526', '__ci_last_regenerate|i:1548567240;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3e79ac5dc46b193019643b62503b5e88056bb2bc', '::1', '1548668977', '__ci_last_regenerate|i:1548668853;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:25:\"Data Deleted Successfully\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3efa9230319421cdf48dad820ae7d774b7ed408e', '::1', '1549439719', '__ci_last_regenerate|i:1549439687;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:71:\"معلومات کو کامیابی سے اپ ڈیٹ کر د یا گیا\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3ff9163f33470b3fe1eab990048050366bf441d5', '::1', '1548668781', '__ci_last_regenerate|i:1548668506;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:25:\"Database Backup Completed\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('40162e5a3e8c5f2161a1d1bc072eff15f607c45d', '::1', '1549005726', '__ci_last_regenerate|i:1549005577;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('40c23dabfd8553fab92a8d75fe7357f40cbcabac', '::1', '1549292053', '__ci_last_regenerate|i:1549291756;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('429f1cbe24c475833d6607a0cc5f0ea681f8401b', '::1', '1548648303', '__ci_last_regenerate|i:1548648169;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('43f8a2754bb5c5560b09bd1ff0fea3c5641e9698', '::1', '1549002449', '__ci_last_regenerate|i:1549002395;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('44550e1549ff3fa884c6df83d0d17c50e8774287', '::1', '1548823493', '__ci_last_regenerate|i:1548823200;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('45ff03173c9c1f783d7bcdb1d65c5e82664830ea', '::1', '1548686181', '__ci_last_regenerate|i:1548685946;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4921716e8072b2d81064e3f5e735326e77e27278', '::1', '1549440041', '__ci_last_regenerate|i:1549439823;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('49c2aadccb426b72032f008a135b332122b863a9', '::1', '1549204249', '__ci_last_regenerate|i:1549204071;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4a6271e6dd61da52fbe24f48e46cac4131a4d00a', '::1', '1549178514', '__ci_last_regenerate|i:1549178494;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4bde2fb0e71fabe7282211ac4d70f8ca34bb43d7', '::1', '1549296527', '__ci_last_regenerate|i:1549296496;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4c898ee891161abc8c8b830ce658fb082a6297d1', '::1', '1548568259', '__ci_last_regenerate|i:1548568006;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4ee4b9b6bc059b052fda5b03a34b639da0c8f808', '::1', '1548669854', '__ci_last_regenerate|i:1548669854;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4f5545f4c4c9973f25aeeec9e20623efdab1da89', '::1', '1549204769', '__ci_last_regenerate|i:1549204692;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('52baf2549089b336f6897842a1a5f4c76f782dcb', '::1', '1548670665', '__ci_last_regenerate|i:1548670375;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('53809870a398914e860ca09def8507860c10f0d5', '::1', '1549461750', '__ci_last_regenerate|i:1549461572;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5394d847d53568000e023654f8e654d07b6aad63', '::1', '1549290010', '__ci_last_regenerate|i:1549289736;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:71:\"معلومات کو کامیابی سے اپ ڈیٹ کر د یا گیا\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('56e78392c77062271fe8eaf59efbeefcf1013297', '::1', '1548652718', '__ci_last_regenerate|i:1548652702;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('596aadf5174560e47d421a31a4b73f7c9ee2dba2', '::1', '1548646730', '__ci_last_regenerate|i:1548646454;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5a431ca9877a11d9fa8233ef48172dc1fc7cdcca', '::1', '1548826304', '__ci_last_regenerate|i:1548826294;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5bdd6548822b1f49a8671235c80bc8bb3adbdde5', '::1', '1549288697', '__ci_last_regenerate|i:1549288593;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d091b71e3f51b5edd65d3d831b85fff76925380', '::1', '1548568609', '__ci_last_regenerate|i:1548568386;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5d6829e39b4c7e4f4bd179c27950838519d4a959', '::1', '1548671322', '__ci_last_regenerate|i:1548671312;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5df5e249f6cf4c21f31c5eb2870196a1a4bc9030', '::1', '1549289682', '__ci_last_regenerate|i:1549289395;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5f5052480a37a387e61caa599ff758b050da6093', '::1', '1549295801', '__ci_last_regenerate|i:1549295788;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('612516fe6968be72d1ef69f8809a7d445ae3833b', '::1', '1548694677', '__ci_last_regenerate|i:1548694421;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:71:\"معلومات کو کامیابی سے اپ ڈیٹ کر د یا گیا\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('613c1522a38dc8cc3a498c27b31a542739a44b1d', '::1', '1549002546', '__ci_last_regenerate|i:1549002496;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('62a3bfb1714e8a940d3d865c2cac723707dbb89a', '::1', '1548822421', '__ci_last_regenerate|i:1548822151;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('63a018894f8577b3e4b1a16917a656e47b1528e4', '::1', '1548688327', '__ci_last_regenerate|i:1548688322;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('63d19957561829d74caf9981556d065d610514c1', '::1', '1548687194', '__ci_last_regenerate|i:1548686944;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('65b2b16458a236e6e914fbedb3b2432ba70bf828', '::1', '1549439676', '__ci_last_regenerate|i:1549439365;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('669cf977d517372727fef23896b0024fe997be45', '::1', '1549205833', '__ci_last_regenerate|i:1549205713;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6770cf2e9692be98cc4bd5224c57b3071f388b32', '::1', '1548695039', '__ci_last_regenerate|i:1548694740;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67d8d8adebaef1ff4f172b697da77d5ed24fa213', '::1', '1549178857', '__ci_last_regenerate|i:1549178569;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('699ecc875ae8d3c84510f84534e82145981a72a3', '::1', '1548564889', '__ci_last_regenerate|i:1548564654;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6a5ec5c4690d3c499b5194adf901a55cd74dcab5', '::1', '1549290344', '__ci_last_regenerate|i:1549290052;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6c0d276cb74dd5cda64823e36b30f03f045238c8', '::1', '1549203036', '__ci_last_regenerate|i:1549202739;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6cca6925e8690ac90f6cce5952b32cd13d131425', '::1', '1548564602', '__ci_last_regenerate|i:1548564348;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6dd9cb577fae9ba9dfd7eaf4be56d7a800acd9a6', '::1', '1548581559', '__ci_last_regenerate|i:1548581559;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('70f79fa03a2ca4a25ebec2df074b1252d843aa87', '::1', '1549003077', '__ci_last_regenerate|i:1549002975;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('72137457eedebe20b6e78b5701d7d1e85b8ece7d', '::1', '1549439787', '__ci_last_regenerate|i:1549439769;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('73ad5e14d3ad4d8fd27dd96447b9c22ccf897274', '::1', '1549365301', '__ci_last_regenerate|i:1549365038;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7619cc7401d9eeebf6f18b736d6f99240672168c', '::1', '1548674211', '__ci_last_regenerate|i:1548673979;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7635505be3ed7750b98d7463ea0e7d14dc87ebd9', '::1', '1548693675', '__ci_last_regenerate|i:1548693412;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('76b73bcd0bfee0d3128613b772759378f3e72386', '::1', '1548648802', '__ci_last_regenerate|i:1548648505;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:25:\"Database Backup Completed\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7a5d180fd4860889cf1852d54d7db0bd598e2259', '::1', '1549005448', '__ci_last_regenerate|i:1549005201;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7a77b442d774ec27508e14e5ef861ba4fd2c30ca', '::1', '1549267024', '__ci_last_regenerate|i:1549266754;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7d891bd2a82e9eaf4c73c9adda16d34a377ac1d3', '::1', '1549296232', '__ci_last_regenerate|i:1549295942;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('809d6e61162ddedfe97c1499f1c9ace37cb618a1', '::1', '1548821104', '__ci_last_regenerate|i:1548820967;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:69:\"صفحہ کو کامیابی سے تبدیل کر دیا گیا۔۔۔\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('812053ef012a55e449a7b0195dd5b3743d164052', '::1', '1549364678', '__ci_last_regenerate|i:1549364541;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('821fa7929e089afc88ce71645bf4ab738ab4141b', '::1', '1549266416', '__ci_last_regenerate|i:1549266136;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('842064c6eb7c6737499abdcfe89632c3e2b21d11', '::1', '1549203673', '__ci_last_regenerate|i:1549203387;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:69:\"صفحہ کو کامیابی سے تبدیل کر دیا گیا۔۔۔\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8589ef7472ef1ac5b7996eb96e23c86bf3f9087f', '::1', '1548575126', '__ci_last_regenerate|i:1548575126;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('882b23df06cea7f3028d6e8a4845132676753702', '::1', '1549460622', '__ci_last_regenerate|i:1549460358;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('884d1c9f6e59bd939d7c087caa3ab5c09485ef37', '::1', '1548821651', '__ci_last_regenerate|i:1548821601;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:25:\"Data Deleted Successfully\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8873732bc2a265632b336adc34f46cf02a4bbe03', '::1', '1548572687', '__ci_last_regenerate|i:1548572458;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8a87c107e7ae4f65c303ceedd6fcd8bc4e84995e', '::1', '1548825515', '__ci_last_regenerate|i:1548825225;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8acea2f22c0766ca5e7e3756f0eb73be5c26c85b', '::1', '1548823914', '__ci_last_regenerate|i:1548823868;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8af98dbba8c51c6410ff20c0bdc613c1b2b6b6ea', '::1', '1548573566', '__ci_last_regenerate|i:1548573402;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8b6da23001963fa339a013d384946942a3a41eb1', '::1', '1549179334', '__ci_last_regenerate|i:1549179242;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8c3e7826bd572110d14bbab0cf108b83728b8288', '::1', '1549292378', '__ci_last_regenerate|i:1549292078;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"new\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8f3c2b8f8dcad75f7192814e8dbc524fc5ca157a', '::1', '1548653398', '__ci_last_regenerate|i:1548653153;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('945f5b8dbd6d91990a498284d7c12fbf8f07deca', '::1', '1549002925', '__ci_last_regenerate|i:1549002637;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('94ce86ac1ff68d8e5089447c78b9db633d1b7bc7', '::1', '1549289715', '__ci_last_regenerate|i:1549289713;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('96b2cd15f0fea09c01c86f851f5e60d1f24e0519', '::1', '1549460879', '__ci_last_regenerate|i:1549460674;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('96b4f0c74a0ecd0f9717d0c5b8b49753aaf4ff2a', '::1', '1548677993', '__ci_last_regenerate|i:1548677928;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:71:\"معلومات کو کامیابی سے اپ ڈیٹ کر د یا گیا\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('976d14cbdbddbc17f42066d774f7ec6e962eaeb3', '::1', '1548672903', '__ci_last_regenerate|i:1548672625;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('984152b4f7287c712d9665c118303897585ebbef', '::1', '1548573991', '__ci_last_regenerate|i:1548573829;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9945264a893432c721d9af891e7bb72469d00663', '::1', '1549295387', '__ci_last_regenerate|i:1549295337;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9bafe17321d237082a87c7b886aab694aa810f22', '::1', '1549296475', '__ci_last_regenerate|i:1549296442;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9c5f50cd6bafe9e2be041098a066cd1da7c60d52', '::1', '1548674863', '__ci_last_regenerate|i:1548674682;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9e9ad6bb17627592205c56914f76da33f522effe', '::1', '1548695990', '__ci_last_regenerate|i:1548695915;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9faf1f1966ac32e993787002e6d6f27c9dbca4fb', '::1', '1548672231', '__ci_last_regenerate|i:1548672201;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a1efade384cde7f23f55a810eb6d46c20bec6f0f', '::1', '1549291142', '__ci_last_regenerate|i:1549290846;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a228244eecf39e5f6fd9c3286ba85025bac82865', '::1', '1548564209', '__ci_last_regenerate|i:1548563934;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a37e58bbf6a7e9f0b981a38b0389425e8bacc062', '::1', '1549353078', '__ci_last_regenerate|i:1549352910;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a3e01ee6f1800a2d42649ad4194338eba5483fa7', '::1', '1549024595', '__ci_last_regenerate|i:1549024314;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a4ba5205fe8ad0d26e2668629eeed5f28da09c2a', '::1', '1548688231', '__ci_last_regenerate|i:1548688003;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a610ad82dfe2f00a639dec538eec1d291cb7951e', '::1', '1548581571', '__ci_last_regenerate|i:1548581559;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a6a078cc4fffd93f4caedeedd6e6a1de6ef2744a', '::1', '1548572138', '__ci_last_regenerate|i:1548571851;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a7933f93940a0d536d615a2470204750fc3a0975', '::1', '1548565130', '__ci_last_regenerate|i:1548565039;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a8a4f6012937177da0fe257b82b22de3d705a7df', '::1', '1549025740', '__ci_last_regenerate|i:1549025442;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a99ef008d8a9fe36611561e2bfb0d510d1ce26fd', '::1', '1549460044', '__ci_last_regenerate|i:1549460002;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aa174aecf3f93177f56f27484bad123fc51b5758', '::1', '1549203342', '__ci_last_regenerate|i:1549203061;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:71:\"معلومات کو کامیابی سے اپ ڈیٹ کر د یا گیا\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aac0a40fa808e68495e812edb18436cea16205b6', '::1', '1548822476', '__ci_last_regenerate|i:1548822476;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ad9880fd5030ea87c10f8af0fbdfdd440b8d17bd', '::1', '1548565866', '__ci_last_regenerate|i:1548565582;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('af7b254e87d067b79aa3ba3d047a5809bab8e011', '::1', '1549179161', '__ci_last_regenerate|i:1549178885;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b14791f40651ee1577c397a8355bc97299028653', '::1', '1549295770', '__ci_last_regenerate|i:1549295758;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b14a1df64addf301527e296ed1f5aea1c5742edf', '::1', '1548563811', '__ci_last_regenerate|i:1548563627;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b2164a177105c9ab55ec7ae43caa1f5a41925939', '::1', '1548823087', '__ci_last_regenerate|i:1548822909;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b2f6eaee7935da563dafd09fd672f4a7202e0629', '::1', '1548695549', '__ci_last_regenerate|i:1548695371;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:71:\"معلومات کو کامیابی سے اپ ڈیٹ کر د یا گیا\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b3d43bdbf7d7341e1002408e803bc5a8add94d39', '::1', '1549005024', '__ci_last_regenerate|i:1549005017;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b8c7cf0cd2b6a886b5f45fd497def6c223752dd0', '::1', '1548669599', '__ci_last_regenerate|i:1548669599;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b9c20b7b3dd372ba496dca5d21c79f6493df0030', '::1', '1549204036', '__ci_last_regenerate|i:1549203736;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bca261dd3c3b41a398aa840024af81b27f4e496f', '::1', '1548686552', '__ci_last_regenerate|i:1548686253;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('be91f6e253a286fbb177148f84da18bb41d9398b', '::1', '1549205248', '__ci_last_regenerate|i:1549205198;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c0cc9ff3fe9bd322f4af8af488aa006b3fd59680', '::1', '1549286692', '__ci_last_regenerate|i:1549286453;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c546116dfb223d5151590df3e412a1ac4b5b66f4', '::1', '1549295512', '__ci_last_regenerate|i:1549295455;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c5d9a5cee2924ae7a962015464953a1537f0ec12', '::1', '1549292720', '__ci_last_regenerate|i:1549292576;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c5e976859af10a9bc514b03b6e5d133810e45746', '::1', '1549295592', '__ci_last_regenerate|i:1549295574;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c7e29420e2b7118ab1457fcc2e27d6331bf28e03', '::1', '1548693200', '__ci_last_regenerate|i:1548692929;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cb6f4bf432314fa45a22197e01be3f5f0dd2e24f', '::1', '1549296296', '__ci_last_regenerate|i:1549296255;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cc83ea80a9be2630e0f12e7f520f65b62f6bb61f', '::1', '1549367027', '__ci_last_regenerate|i:1549366929;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cd0cdae27af097843e5842b964e6f3808a654db1', '::1', '1548673315', '__ci_last_regenerate|i:1548673250;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cf4cb50bf5144a7b73c85f4b48c0dd4e3fc92c0f', '::1', '1548821741', '__ci_last_regenerate|i:1548821671;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";error_message|s:49:\"یہ صفحہ پہلے سے موجود ہے۔۔۔\";__ci_vars|a:1:{s:13:\"error_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d0ad739bbf2f73afd21ed12ed33e18524fefa92c', '::1', '1549440163', '__ci_last_regenerate|i:1549440140;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d12aa4795a3b96e28812e45c04718e1ed01fb3fc', '::1', '1548574541', '__ci_last_regenerate|i:1548574271;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d12e6c99fd04fbb6204f2b5ae5f05aee40862c95', '::1', '1548822855', '__ci_last_regenerate|i:1548822577;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d4d4b34b8279f901d55a70297a19a6d1d8698619', '::1', '1548687583', '__ci_last_regenerate|i:1548687354;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5021c1fe4e9cc453764814d588359f1225cfa45', '::1', '1548823823', '__ci_last_regenerate|i:1548823547;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5610416871169409e5fdd88769f301ac1ee5e6f', '::1', '1548694207', '__ci_last_regenerate|i:1548694188;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d56116ee96e4664d8a9152fb15f3b031ab3ecb62', '::1', '1548573386', '__ci_last_regenerate|i:1548573093;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d618b38d58418f4ff6e9eab652703ea2b3fb9147', '::1', '1548824565', '__ci_last_regenerate|i:1548824403;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d7ab5ff7d97877cc8652ea4e2b32327467807b20', '::1', '1548695310', '__ci_last_regenerate|i:1548695059;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d7cb35ed4aed0d15dbee8fac2ab86b0644e96419', '::1', '1549290419', '__ci_last_regenerate|i:1549290371;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d96d210700a81eec1b1437c014b768ecbd14a863', '::1', '1549025429', '__ci_last_regenerate|i:1549025298;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d9c5823f83ec5bc222ed5c53172d7aa26b3c6e43', '::1', '1549289382', '__ci_last_regenerate|i:1549289348;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dc403aad0c49f2ee77e5a14af2c3f9b3301c1a96', '::1', '1549204577', '__ci_last_regenerate|i:1549204576;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dd73b1c5b343e298d8e1b6dab915ae67286a52ce', '::1', '1548695888', '__ci_last_regenerate|i:1548695657;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('debd5a7d6afe33bf65120646286ba2f374471533', '::1', '1548669343', '__ci_last_regenerate|i:1548669032;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e0c72b122b768c82a2a10fa063c5df73943e1e5e', '::1', '1549205547', '__ci_last_regenerate|i:1549205277;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e1c25e076e8b9a6ab124ae59abe94acbe0d67563', '::1', '1549202174', '__ci_last_regenerate|i:1549202153;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e3161f3470898cabaf60613875bb9deb30dc652f', '::1', '1548686884', '__ci_last_regenerate|i:1548686608;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e8724113413dd2a492cd65e042866651b2d44fa5', '::1', '1548571786', '__ci_last_regenerate|i:1548571541;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e9b56c1b9a5f4bff347c464916cf18777583ac35', '::1', '1549289025', '__ci_last_regenerate|i:1549288735;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ead13977edbbd259850b216f6bb2fbacb75a92d5', '::1', '1549006112', '__ci_last_regenerate|i:1549006109;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eb9a7f085647269d28dd9c74cf5d286b893af908', '::1', '1548567550', '__ci_last_regenerate|i:1548567549;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ed51c191877096f393faf019d3a772fbbbd46ad9', '::1', '1549005009', '__ci_last_regenerate|i:1549004898;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('edca16ee5b071b3e3c2bc915a5adb64bf4ad9e35', '::1', '1548566097', '__ci_last_regenerate|i:1548565888;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ef199c9a2855bf467e704fda974375a39ec8fcc7', '::1', '1548693322', '__ci_last_regenerate|i:1548693297;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ef1d479e6a3ba7f456355de96111e4328d882c35', '::1', '1549006623', '__ci_last_regenerate|i:1549006447;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('efc803d4a0f2ca187d093f8be351d3859e3d64da', '::1', '1549295538', '__ci_last_regenerate|i:1549295521;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f0c77d31fd0e837227a60d74cf518281b298163a', '::1', '1548652694', '__ci_last_regenerate|i:1548652400;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f1bdf37414f98133c755e2af2211e8ba95fe0e91', '::1', '1549365970', '__ci_last_regenerate|i:1549365684;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f290c088572e52656f37fe78bac4baeaed3a1c97', '::1', '1549024258', '__ci_last_regenerate|i:1549023959;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3c3e2a4d7a9c30cb7c16380819d74e154ed7d60', '::1', '1548571353', '__ci_last_regenerate|i:1548571118;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f3d1fd6fd5ee758fcc4520e34291964795403ae7', '::1', '1548687944', '__ci_last_regenerate|i:1548687662;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f5bf2c672fd0fbaa71ba3d5db42c37a469eb3ab0', '::1', '1549364987', '__ci_last_regenerate|i:1549364702;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f73ad49dac2565ea0766e44202f566475b3bf2bf', '::1', '1548572319', '__ci_last_regenerate|i:1548572155;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f7954f40898a451e9b4424407bc9e05761e3475a', '::1', '1548824967', '__ci_last_regenerate|i:1548824668;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f7bb14184dc1c479ee7aa50ccd767bd250847f2f', '::1', '1549286924', '__ci_last_regenerate|i:1549286923;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f8ffe80bd349ebcd659bb8eddba6ae7d3b7d8bfe', '::1', '1549006100', '__ci_last_regenerate|i:1549005803;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:68:\"معلومات کو کامیابی سے شامل کر د یے گیے\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f9ace3ebff5597d02a11395677784841995ef646', '::1', '1548671002', '__ci_last_regenerate|i:1548670717;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fa1e8a537338660c3b7b08a4ac35def3682410a7', '::1', '1548649371', '__ci_last_regenerate|i:1548649139;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";flash_message|s:25:\"Database Backup Completed\";__ci_vars|a:1:{s:13:\"flash_message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fa68945b4c4169a8e5968889e8337d1845ef3a63', '::1', '1548566453', '__ci_last_regenerate|i:1548566196;admin_login|s:1:\"1\";admin_id|s:1:\"1\";login_user_id|s:1:\"1\";name|s:16:\"اکاونٹنٹ\";login_type|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fc75e6735a594a260f469d70722966116d83a7bb', '::1', '1548653686', '__ci_last_regenerate|i:1548653686;');


#
# TABLE STRUCTURE FOR: expenses_category
#

DROP TABLE IF EXISTS `expenses_category`;

CREATE TABLE `expenses_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf8 NOT NULL,
  `comment` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `expenses_category` (`id`, `name`, `comment`) VALUES ('1', 'واجبی اخراجات', '');
INSERT INTO `expenses_category` (`id`, `name`, `comment`) VALUES ('2', 'عمومی اخراجات', '');
INSERT INTO `expenses_category` (`id`, `name`, `comment`) VALUES ('3', 'ترقیا تی اخراجات', '');


#
# TABLE STRUCTURE FOR: income
#

DROP TABLE IF EXISTS `income`;

CREATE TABLE `income` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `income_category_id` int(11) NOT NULL,
  `bill_no` int(11) NOT NULL,
  `date` date NOT NULL,
  `assistant` longtext CHARACTER SET utf8 NOT NULL,
  `amount` int(11) NOT NULL,
  `arabic_month` int(11) NOT NULL,
  `arabic_date` date NOT NULL,
  `comment` longtext CHARACTER SET utf8 NOT NULL,
  `year` longtext CHARACTER SET utf8 NOT NULL,
  `talimi_saal` int(11) NOT NULL,
  `page_num` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('1', '1', '68061', '2018-06-15', ' شمس الرحمن  پشاور', '1000', '10', '1439-10-01', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('2', '1', '68062', '2018-06-15', ' عباس علی    پشاور', '1500', '10', '1439-10-01', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('3', '1', '68063', '2018-06-15', ' خوانی صاحب  پشاور', '500', '10', '1439-10-01', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('4', '1', '68064', '2018-06-15', 'بندہ خدا پشاور', '400', '10', '1439-10-01', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('5', '1', '68065', '2018-06-15', ' نواز صاحب پشاور', '500', '10', '1439-10-01', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('6', '1', '68066', '2018-06-15', 'محمد نظام الدین  پشاور', '800', '10', '1439-10-01', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('7', '1', '68067', '2018-06-15', 'اعزاز الرحمن  پشاور', '400', '10', '1439-10-01', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('8', '1', '68068', '2018-06-15', ' نعمت اللہ صاحب پشاور', '500', '10', '1439-10-01', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('9', '1', '68069', '2018-06-16', ' عاصم اعجاز صاحب پشاور', '4000', '10', '1439-10-02', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('10', '1', '68070', '2018-06-16', ' ملک اعجاز صاحب پشاور', '5000', '10', '1439-10-02', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('11', '1', '68071', '2018-06-16', 'گل شہزادہ صاحب پشاور', '1000', '10', '1439-10-02', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('12', '1', '68072', '2018-06-16', ' شاہ اسلام صاحب پشاور', '1500', '10', '1439-10-02', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('13', '1', '68073', '2018-06-17', 'زوجہ عبدالرحیم پشاور', '1000', '10', '1439-10-03', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('14', '2', '68074', '2018-06-17', 'رضاء الحق پشاور', '500', '10', '1439-10-03', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('15', '1', '68075', '2018-06-17', ' حاجی سعید صاحب پشاور', '10000', '10', '1439-10-03', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('16', '2', '68076', '2018-06-17', 'صدیق احمد صاحب پشاور', '500', '10', '1439-10-03', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('17', '1', '68077', '2018-06-19', ' حمایت اللہ صاحب  پشاور', '11000', '10', '1439-10-05', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('18', '2', '68078', '2018-06-21', ' محمد وقاص پشاور', '1000', '10', '1439-10-07', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('19', '2', '68079', '2018-06-21', 'شمس الامین تیمرگرہ', '1000', '10', '1439-10-07', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('20', '1', '68080', '2018-06-21', 'بمع عزیر بادشاہ پشاور', '55000', '10', '1439-10-07', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('21', '1', '68081', '2018-06-23', ' ثاقب اللہ  نوشہرہ', '1000', '10', '1439-10-09', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('22', '1', '68082', '2018-06-24', ' لعل محمد صاحب پشاو', '20000', '10', '1439-10-10', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('23', '1', '68083', '2018-06-24', ' محمد زکریا صاحب بونیر', '43000', '10', '1439-10-10', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('24', '1', '68084', '2018-06-24', ' ظہور اکرم صاحب پشاور', '1900', '10', '1439-10-10', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('25', '2', '68085', '2018-06-25', 'بمع  جمشید  پشاور', '1500', '10', '1439-10-11', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('26', '1', '68086', '2018-06-26', ' محمد غفران صاحب پشاور', '5000', '10', '1439-10-12', '', '1439-1440', '27', '1');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('27', '2', '68087', '2018-06-27', 'جناب مولانا رضوان اللہ صاحب', '3000', '10', '1439-10-13', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('28', '1', '68088', '2018-06-27', 'جناب نثارصاحب ملیشیاء', '30000', '10', '1439-10-13', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('29', '1', '68089', '2018-06-27', 'جناب احمد علی ملیشیاء', '50000', '10', '1439-10-13', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('30', '2', '68090', '2018-06-28', 'ڈاکٹر زبیر صاحب پشاور', '3000', '10', '1439-10-14', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('31', '2', '68091', '2018-06-28', 'ڈاکٹر عبید الرحمن صاحب پشاور', '6000', '10', '1439-10-14', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('32', '1', '68092', '2018-06-28', 'جناب زبیر علی پشاور', '300000', '10', '1439-10-14', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('33', '2', '68093', '2018-06-28', 'جناب زبیر علی پشاور', '50000', '10', '1439-10-14', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('34', '1', '68094', '2019-02-05', 'زوجہ محمد طفیل محمد پشاور', '5000', '10', '1440-05-29', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('35', '1', '68095', '2018-05-01', 'جناب رحمن گل صاحب پشاور', '30000', '10', '1439-08-15', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('36', '2', '68096', '2018-07-01', 'جناب عبدالرشید پشاور', '2200', '10', '1439-10-17', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('37', '2', '68097', '2018-07-02', 'جناب سلطان زیب پشاور', '3000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('38', '2', '68098', '2018-07-02', 'جناب افضال صاحب پشاور', '75000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('39', '2', '68099', '2018-07-02', 'سہیل احمد صاھب پشاور', '10000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('40', '2', '68100', '2018-07-02', 'طفیل احمد صاحب پشاور', '1000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('41', '2', '68101', '2018-07-02', 'بندہ خدا پشاور', '40000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('42', '2', '68102', '2018-07-02', 'حاجی عنایت اللہ صاح پشاور', '10000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('43', '2', '68103', '2018-07-02', 'ڈاکٹر خالد محمود صاح پشاور', '10000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('44', '2', '68104', '2018-07-02', 'حاجی قاسم صاحب کراچی', '30000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('45', '2', '68105', '2018-07-02', 'جناب بابرمجید پشاور', '1000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('46', '1', '68106', '2018-07-02', 'جناب ظاہر شاہ مردان', '10000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('47', '2', '68107', '2018-07-02', 'حاجی ظاہرشاہ پشاور', '10000', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('48', '1', '68108', '2018-07-02', 'حیات خان صاحب پشاور', '500', '10', '1439-10-18', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('49', '1', '68109', '2018-07-03', 'حاجی ممتاز صاحب پشاور', '50000', '10', '1439-10-19', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('50', '2', '68110', '2018-07-03', 'محمد یعقوب خٹک پشاور', '500', '10', '1439-10-19', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('51', '1', '68111', '2018-07-03', 'جناب عبداللہ صاحب پشاور', '1000', '10', '1439-10-19', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('52', '2', '68112', '2018-07-03', 'جناب خیرولی نوشہرہ', '10000', '10', '1439-10-19', '', '1439-1440', '27', '2');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('53', '2', '68113', '2018-07-04', 'جناب محمد حماد صوابی', '20000', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `income` (`id`, `income_category_id`, `bill_no`, `date`, `assistant`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('54', '1', '68114', '2018-07-04', 'حاجی گل آفتاب صاحب پشاور', '500', '10', '1439-10-20', '', '1439-1440', '27', '3');


#
# TABLE STRUCTURE FOR: income_category
#

DROP TABLE IF EXISTS `income_category`;

CREATE TABLE `income_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf8 NOT NULL,
  `comment` longtext CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `income_category` (`id`, `name`, `comment`) VALUES ('1', 'صدقات واجبہ', '');
INSERT INTO `income_category` (`id`, `name`, `comment`) VALUES ('2', 'عطیات', '');
INSERT INTO `income_category` (`id`, `name`, `comment`) VALUES ('3', 'وصولی ماہانہ اخراجات', '');
INSERT INTO `income_category` (`id`, `name`, `comment`) VALUES ('4', 'العصر', '');


#
# TABLE STRUCTURE FOR: income_page_lock
#

DROP TABLE IF EXISTS `income_page_lock`;

CREATE TABLE `income_page_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `year` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `income_page_lock` (`id`, `number`, `status`, `year`) VALUES ('1', '1', '0', '1439-1440');
INSERT INTO `income_page_lock` (`id`, `number`, `status`, `year`) VALUES ('2', '2', '0', '1439-1440');
INSERT INTO `income_page_lock` (`id`, `number`, `status`, `year`) VALUES ('3', '3', '1', '1439-1440');


#
# TABLE STRUCTURE FOR: jamia_expenses
#

DROP TABLE IF EXISTS `jamia_expenses`;

CREATE TABLE `jamia_expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_category_id` int(11) NOT NULL,
  `child_expense_id` int(11) NOT NULL,
  `sub_child_expense_id` int(11) NOT NULL,
  `bill_no` int(11) NOT NULL,
  `date` date NOT NULL,
  `amount` int(11) NOT NULL,
  `arabic_month` int(11) NOT NULL,
  `arabic_date` date NOT NULL,
  `comment` longtext CHARACTER SET utf8,
  `year` longtext CHARACTER SET utf8 NOT NULL,
  `talimi_saal` int(11) NOT NULL,
  `page_num` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `expense_category_id` (`expense_category_id`),
  KEY `child_expense_id` (`child_expense_id`),
  KEY `sub_child_expense_id` (`sub_child_expense_id`),
  KEY `arabic_month` (`arabic_month`)
) ENGINE=InnoDB AUTO_INCREMENT=361 DEFAULT CHARSET=latin1;

INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('14', '1', '3', '3', '1', '2018-06-16', '23300', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('15', '1', '3', '3', '2', '2018-06-16', '22295', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('16', '2', '12', '12', '3', '2018-06-16', '2400', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('17', '1', '1', '1', '4', '2018-06-16', '42532', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('18', '2', '12', '12', '5', '2018-06-16', '5000', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('19', '1', '8', '8', '6', '2018-06-16', '5340', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('20', '1', '2', '2', '7', '2018-06-16', '12710', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('21', '2', '15', '15', '8', '2018-06-16', '23750', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('22', '1', '1', '1', '9', '2018-06-16', '84462', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('23', '1', '3', '3', '10', '2018-06-16', '118230', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('24', '1', '3', '3', '11', '2018-06-16', '25255', '10', '1439-10-02', '', '1439-1440', '27', '2');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('25', '2', '13', '13', '12', '2018-07-04', '3120', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('26', '1', '2', '2', '13', '2018-07-04', '7540', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('27', '2', '13', '13', '14', '2018-07-04', '9120', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('28', '3', '21', '23', '15', '2018-07-04', '4600', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('29', '1', '9', '9', '16', '2018-07-04', '12560', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('30', '3', '20', '22', '17', '2018-07-04', '3130', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('31', '1', '7', '7', '18', '2018-07-04', '1500', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('32', '1', '3', '3', '19', '2018-07-04', '193877', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('33', '1', '3', '3', '20', '2018-07-04', '314546', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('34', '1', '8', '8', '21', '2018-07-04', '13877', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('35', '1', '2', '2', '22', '2018-07-04', '6000', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('36', '1', '9', '9', '23', '2018-07-04', '880', '10', '1439-10-20', '', '1439-1440', '27', '3');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('37', '1', '8', '8', '24', '2018-07-14', '6740', '10', '1439-11-01', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('38', '3', '26', '19', '25', '2018-07-14', '8240', '10', '1439-11-01', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('39', '3', '21', '23', '26', '2018-07-14', '650', '10', '1439-11-01', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('40', '3', '26', '19', '27', '2018-07-14', '85330', '10', '1439-11-01', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('41', '3', '25', '17', '28', '2018-07-14', '920', '10', '1439-11-01', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('42', '1', '3', '3', '29', '2018-07-14', '58120', '10', '1439-11-01', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('43', '1', '3', '3', '30', '2018-07-14', '227420', '10', '1439-11-01', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('44', '1', '6', '6', '31', '2018-07-14', '10940', '10', '1439-11-01', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('45', '2', '13', '13', '32', '2018-07-14', '850', '10', '1439-11-01', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('46', '1', '8', '8', '33', '2018-07-14', '30300', '10', '1439-11-01', '', '1439-1440', '27', '4');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('47', '1', '9', '9', '34', '2018-07-18', '560', '10', '1439-11-05', '', '1439-1440', '27', '5');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('48', '2', '13', '13', '35', '2018-07-18', '3620', '10', '1439-11-05', '', '1439-1440', '27', '5');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('49', '1', '8', '8', '36', '2018-07-18', '22500', '10', '1439-11-05', '', '1439-1440', '27', '5');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('50', '1', '4', '4', '37', '2018-07-18', '887650', '10', '1439-11-05', '', '1439-1440', '27', '5');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('51', '2', '15', '15', '38', '2018-07-18', '6730', '10', '1439-11-05', '', '1439-1440', '27', '5');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('52', '1', '8', '8', '39', '2018-07-18', '930', '10', '1439-11-05', '', '1439-1440', '27', '5');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('53', '2', '13', '13', '40', '2018-07-18', '6385', '10', '1439-11-05', '', '1439-1440', '27', '5');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('54', '1', '3', '3', '41', '2018-07-18', '1310', '10', '1439-11-05', '', '1439-1440', '27', '5');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('55', '2', '11', '11', '42', '2018-07-22', '26650', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('56', '1', '8', '8', '43', '2018-07-22', '12871', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('57', '3', '26', '19', '44', '2018-07-22', '3200', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('58', '2', '12', '12', '45', '2018-07-22', '3000', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('59', '1', '3', '3', '46', '2018-07-22', '150090', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('60', '3', '21', '23', '47', '2018-07-22', '39890', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('61', '1', '9', '9', '48', '2018-07-22', '3520', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('62', '1', '1', '1', '49', '2018-07-22', '63337', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('63', '1', '2', '2', '50', '2018-07-22', '9000', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('64', '1', '3', '3', '51', '2018-07-22', '213709', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('65', '3', '26', '19', '52', '2018-07-22', '3330', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('66', '2', '15', '15', '53', '2018-07-22', '7000', '11', '1439-11-09', '', '1439-1440', '27', '6');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('67', '3', '20', '22', '54', '2018-08-01', '25760', '11', '1439-11-19', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('68', '1', '3', '3', '55', '2018-08-01', '4190', '11', '1439-11-19', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('69', '2', '13', '13', '56', '2018-08-01', '13348', '11', '1439-11-19', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('70', '1', '8', '8', '57', '2018-08-01', '4880', '11', '1439-12-11', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('71', '1', '3', '3', '58', '2018-08-01', '261430', '11', '1439-11-19', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('72', '1', '6', '6', '59', '2018-08-08', '1300', '11', '1439-11-26', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('73', '3', '21', '23', '60', '2018-08-08', '7920', '11', '1439-11-26', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('74', '1', '2', '2', '61', '2018-08-08', '12590', '11', '1439-11-26', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('75', '1', '1', '1', '62', '2018-08-08', '89667', '11', '1439-11-26', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('76', '3', '26', '19', '63', '2018-08-08', '22910', '11', '1439-11-26', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('77', '1', '3', '3', '64', '2018-08-08', '269735', '11', '1439-11-26', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('78', '1', '9', '9', '65', '2018-08-08', '3200', '11', '1439-11-26', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('79', '2', '15', '15', '66', '2018-08-08', '6500', '11', '1439-11-26', '', '1439-1440', '27', '7');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('80', '1', '9', '9', '67', '2018-08-12', '31380', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('81', '3', '16', '16', '68', '2018-08-12', '164035', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('82', '3', '16', '16', '69', '2018-08-12', '91020', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('83', '1', '6', '6', '70', '2018-08-12', '450', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('84', '2', '12', '12', '71', '2018-08-12', '11000', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('85', '1', '2', '2', '72', '2018-08-12', '20100', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('86', '1', '3', '3', '73', '2018-08-12', '71090', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('87', '1', '2', '2', '74', '2018-08-12', '6000', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('88', '3', '21', '23', '75', '2018-08-12', '33250', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('89', '3', '25', '17', '76', '2018-08-12', '1030', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('90', '1', '8', '8', '77', '2018-08-12', '9153', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('91', '3', '16', '16', '78', '2018-08-12', '281030', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('92', '3', '26', '19', '79', '2018-08-12', '12630', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('93', '2', '12', '12', '80', '2018-08-12', '5000', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('94', '3', '20', '22', '81', '2018-08-12', '500', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('95', '3', '16', '16', '82', '2018-08-12', '43580', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('96', '1', '5', '5', '83', '2018-08-12', '1150', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('97', '2', '13', '13', '84', '2019-02-01', '2260', '11', '1440-05-25', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('98', '2', '13', '13', '85', '2018-08-12', '4159', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('99', '1', '3', '3', '86', '2018-08-12', '4820', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('100', '1', '3', '3', '87', '2018-08-12', '135040', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('101', '1', '4', '4', '88', '2018-08-12', '885757', '11', '1439-11-30', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('102', '3', '20', '22', '89', '2018-08-12', '1500', '11', '1439-12-01', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('103', '1', '8', '8', '90', '2018-08-12', '2500', '11', '1439-12-01', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('104', '2', '10', '10', '91', '2018-08-12', '1690', '11', '1439-11-30', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('105', '1', '3', '3', '92', '2018-08-12', '328805', '11', '1439-11-30', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('106', '2', '15', '15', '93', '2018-08-12', '890', '11', '1439-11-30', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('107', '3', '21', '23', '94', '2018-08-12', '47050', '11', '1439-11-30', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('108', '3', '26', '19', '95', '2018-08-12', '6230', '11', '1439-11-30', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('109', '2', '13', '13', '96', '2018-08-12', '9308', '11', '1439-11-30', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('110', '1', '9', '9', '97', '2018-08-12', '2900', '11', '1439-11-30', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('111', '1', '3', '3', '98', '2018-08-12', '4190', '11', '1439-11-30', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('112', '1', '3', '3', '99', '2018-08-12', '249160', '11', '1439-11-30', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('113', '3', '26', '19', '100', '2018-08-13', '210', '12', '1439-12-01', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('114', '3', '16', '16', '101', '2018-08-13', '324640', '12', '1439-12-01', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('115', '1', '3', '3', '102', '2018-08-13', '51515', '12', '1439-12-01', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('116', '2', '11', '11', '103', '2018-08-13', '27930', '12', '1439-12-01', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('117', '1', '8', '8', '104', '2018-08-13', '8230', '12', '1439-12-01', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('118', '3', '16', '16', '105', '2018-08-13', '133570', '12', '1439-12-01', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('119', '2', '15', '15', '106', '2018-08-13', '11725', '12', '1439-12-01', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('120', '1', '1', '1', '107', '2018-08-13', '176452', '12', '1439-12-01', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('121', '1', '8', '8', '108', '2018-08-13', '700', '12', '1439-12-01', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('122', '1', '9', '9', '109', '2018-08-13', '50', '12', '1439-12-01', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('123', '1', '8', '8', '110', '2018-08-13', '20090', '12', '1439-12-01', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('124', '1', '8', '8', '111', '2018-08-13', '6552', '12', '1439-12-01', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('125', '3', '25', '17', '112', '2018-08-13', '920', '12', '1439-12-01', '', '1439-1440', '27', '8');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('126', '2', '13', '13', '113', '2018-09-05', '8560', '12', '1439-12-24', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('127', '1', '9', '9', '114', '2018-09-05', '22340', '12', '1439-12-24', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('128', '1', '3', '3', '115', '2019-02-05', '27588', '12', '1440-05-29', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('129', '1', '6', '6', '116', '2018-09-05', '4560', '12', '1439-12-24', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('130', '1', '8', '8', '117', '2019-02-01', '31170', '12', '1440-05-25', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('131', '3', '16', '16', '118', '2018-09-05', '85250', '12', '1439-12-24', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('132', '2', '15', '15', '119', '2019-02-01', '17380', '12', '1440-05-25', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('133', '1', '2', '2', '120', '2018-09-05', '37530', '12', '1439-12-24', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('134', '1', '3', '3', '121', '2018-09-05', '179245', '12', '1439-12-24', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('135', '3', '21', '23', '122', '2018-09-05', '19150', '12', '1439-12-24', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('136', '3', '21', '23', '123', '2018-09-05', '480', '12', '1439-12-24', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('137', '3', '16', '16', '124', '2018-09-05', '77360', '12', '1439-12-24', '', '1439-1440', '27', '9');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('138', '1', '2', '2', '125', '2018-09-11', '8740', '12', '1439-12-24', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('139', '1', '8', '8', '126', '2018-09-11', '6714', '12', '1439-12-24', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('140', '3', '26', '19', '127', '2018-09-05', '5700', '12', '1439-12-24', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('141', '3', '26', '19', '128', '2018-09-05', '1200', '12', '1439-12-24', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('142', '1', '3', '3', '129', '2018-09-11', '55080', '12', '1439-12-30', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('143', '1', '3', '3', '130', '2018-09-11', '3020', '12', '1439-12-30', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('144', '2', '13', '13', '131', '2018-09-11', '17', '12', '1439-12-30', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('145', '2', '12', '12', '132', '2018-09-11', '5500', '12', '1439-12-30', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('146', '1', '4', '4', '133', '2019-02-03', '910550', '12', '1440-05-27', '', '1439-1440', '27', '10');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('147', '1', '9', '9', '134', '2018-09-11', '1840', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('148', '1', '3', '3', '135', '2018-09-11', '109935', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('149', '1', '2', '2', '136', '2018-09-11', '60220', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('150', '1', '1', '1', '137', '2018-09-11', '117595', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('151', '1', '3', '3', '138', '2018-09-11', '2700', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('152', '3', '20', '22', '139', '2018-09-11', '28350', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('153', '1', '8', '8', '140', '2018-09-11', '9607', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('154', '3', '26', '19', '141', '2018-09-11', '10150', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('155', '3', '20', '22', '142', '2019-02-03', '820', '12', '1440-05-27', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('156', '1', '3', '3', '143', '2018-09-11', '167990', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('157', '2', '15', '15', '144', '2018-09-11', '1000', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('158', '1', '8', '8', '145', '2018-09-11', '1000', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('159', '2', '13', '13', '146', '2018-09-11', '10919', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('160', '1', '3', '3', '147', '2018-09-11', '4800', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('161', '1', '3', '3', '148', '2018-09-11', '244950', '12', '1439-12-30', '', '1439-1440', '27', '11');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('162', '3', '16', '16', '149', '2018-09-13', '141950', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('163', '1', '5', '5', '150', '2018-09-13', '1610', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('164', '2', '12', '12', '151', '2018-09-13', '4500', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('165', '1', '3', '3', '152', '2018-09-13', '201780', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('167', '2', '11', '11', '153', '2018-09-13', '27850', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('168', '3', '16', '16', '154', '2018-09-13', '97920', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('169', '2', '13', '13', '155', '2018-09-13', '3235', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('170', '1', '1', '1', '156', '2018-09-13', '179782', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('171', '1', '8', '8', '157', '2018-09-13', '12180', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('172', '1', '7', '7', '158', '2018-09-13', '1880', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('173', '1', '9', '9', '159', '2018-09-13', '10630', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('174', '1', '6', '6', '160', '2018-09-13', '4770', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('175', '1', '6', '6', '161', '2018-09-13', '500', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('176', '3', '26', '19', '162', '2018-09-13', '200', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('177', '1', '7', '7', '163', '2018-09-13', '4150', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('178', '3', '21', '23', '164', '2018-09-13', '21525', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('179', '1', '8', '8', '165', '2018-09-13', '4230', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('180', '1', '3', '3', '166', '2018-09-13', '111136', '1', '1440-01-02', '', '1439-1440', '27', '12');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('181', '3', '22', '24', '167', '2018-10-01', '16050', '1', '1440-01-02', '', '1439-1440', '27', '13');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('182', '3', '20', '22', '168', '2018-09-13', '28200', '1', '1440-01-02', '', '1439-1440', '27', '13');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('183', '1', '2', '2', '169', '2018-10-01', '44780', '1', '1440-01-20', '', '1439-1440', '27', '13');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('184', '3', '26', '19', '170', '2018-10-01', '3980', '1', '1440-01-20', '', '1439-1440', '27', '13');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('185', '1', '8', '8', '171', '2018-10-01', '3160', '1', '1440-01-20', '', '1439-1440', '27', '13');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('186', '1', '9', '9', '172', '2018-10-01', '17000', '1', '1440-01-20', '', '1439-1440', '27', '13');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('187', '1', '3', '3', '173', '2018-10-01', '254995', '1', '1440-01-20', '', '1439-1440', '27', '13');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('188', '1', '1', '1', '174', '2018-10-01', '229539', '1', '1440-01-20', '', '1439-1440', '27', '13');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('189', '2', '13', '13', '175', '2018-10-01', '5640', '1', '1440-01-20', '', '1439-1440', '27', '13');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('190', '1', '3', '3', '176', '2018-10-01', '285305', '1', '1440-01-20', '', '1439-1440', '27', '13');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('191', '2', '12', '12', '177', '2018-10-01', '114370', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('192', '3', '16', '16', '178', '2018-10-01', '95400', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('193', '1', '3', '3', '179', '2018-10-01', '203430', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('194', '1', '9', '9', '180', '2019-02-03', '1020', '1', '1440-05-27', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('195', '2', '15', '15', '181', '2018-10-01', '14500', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('196', '3', '25', '17', '182', '2018-10-01', '970', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('197', '1', '2', '2', '183', '2018-10-01', '2460', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('198', '1', '2', '2', '184', '2018-10-01', '27300', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('199', '3', '26', '19', '185', '2018-10-01', '3040', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('200', '3', '16', '16', '186', '2018-10-01', '337500', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('201', '1', '7', '7', '187', '2018-10-01', '820', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('202', '1', '8', '8', '188', '2018-10-01', '6590', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('203', '1', '8', '8', '189', '2018-10-01', '1200', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('204', '1', '3', '3', '190', '2018-10-01', '53280', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('205', '2', '13', '13', '191', '2018-10-01', '4292', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('206', '1', '3', '3', '192', '2018-10-01', '4960', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('207', '3', '16', '16', '193', '2018-10-01', '92300', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('208', '2', '12', '12', '194', '2018-10-01', '5500', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('209', '1', '4', '4', '195', '2018-10-01', '910550', '1', '1440-01-20', '', '1439-1440', '27', '14');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('210', '1', '3', '3', '196', '2018-10-10', '259917', '1', '1440-01-29', '', '1439-1440', '27', '15');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('211', '3', '26', '19', '197', '2018-10-10', '1680', '1', '1440-01-29', '', '1439-1440', '27', '15');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('212', '3', '20', '22', '198', '2018-10-10', '1640', '1', '1440-01-29', '', '1439-1440', '27', '15');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('213', '2', '13', '13', '199', '2018-10-10', '1950', '1', '1440-01-29', '', '1439-1440', '27', '15');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('214', '1', '8', '8', '200', '2018-10-10', '7303', '1', '1440-01-29', '', '1439-1440', '27', '15');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('215', '1', '3', '3', '201', '2018-10-10', '3650', '1', '1440-01-29', '', '1439-1440', '27', '15');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('216', '2', '13', '13', '202', '2018-10-10', '16819', '1', '1440-01-29', '', '1439-1440', '27', '15');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('217', '1', '3', '3', '203', '2018-10-10', '275817', '1', '1440-01-29', '', '1439-1440', '27', '15');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('218', '2', '12', '12', '204', '2018-10-10', '6000', '1', '1440-01-29', '', '1439-1440', '27', '15');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('219', '2', '15', '15', '205', '2018-10-11', '500', '2', '1440-01-30', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('220', '1', '8', '8', '206', '2018-10-11', '16880', '2', '1440-01-30', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('221', '1', '3', '3', '207', '2018-10-11', '139312', '2', '1440-01-30', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('222', '1', '9', '9', '208', '2018-10-11', '2770', '2', '1440-01-30', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('223', '1', '9', '9', '209', '2018-10-11', '9580', '2', '1440-01-30', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('224', '1', '5', '5', '210', '2018-10-11', '1890', '2', '1440-01-30', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('225', '2', '13', '13', '211', '2018-10-11', '3560', '2', '1440-01-30', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('226', '3', '26', '19', '212', '2018-10-11', '3190', '2', '1440-01-30', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('227', '2', '11', '11', '213', '2018-10-11', '28250', '2', '1440-01-30', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('228', '1', '7', '7', '214', '2018-10-14', '395', '2', '1440-02-03', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('229', '1', '1', '1', '215', '2018-10-11', '175350', '2', '1440-01-30', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('230', '1', '6', '6', '216', '2018-10-14', '4940', '2', '1440-02-03', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('231', '1', '3', '3', '217', '2018-10-14', '133638', '2', '1440-02-03', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('232', '1', '2', '2', '218', '2018-10-14', '11210', '2', '1440-02-03', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('233', '1', '8', '8', '219', '2018-10-14', '2400', '2', '1440-02-03', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('234', '1', '6', '6', '220', '2018-10-14', '0', '2', '1440-02-03', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('235', '3', '26', '19', '221', '2018-10-14', '33000', '2', '1440-02-03', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('236', '1', '2', '2', '222', '2018-10-14', '59410', '2', '1440-02-03', '', '1439-1440', '27', '16');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('237', '1', '2', '2', '223', '2018-10-21', '1960', '2', '1440-02-10', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('238', '2', '15', '15', '224', '2018-10-21', '1500', '2', '1440-02-10', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('239', '1', '1', '1', '225', '2018-10-21', '226310', '2', '1440-02-10', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('240', '1', '6', '6', '226', '2018-10-21', '2850', '2', '1440-02-10', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('241', '1', '2', '2', '227', '2018-10-21', '72480', '2', '1440-02-10', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('242', '1', '8', '8', '228', '2018-10-21', '11170', '2', '1440-02-10', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('243', '1', '3', '3', '229', '2018-10-21', '290287', '2', '1440-02-10', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('244', '2', '13', '13', '230', '2018-10-21', '3060', '2', '1440-02-10', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('245', '3', '26', '19', '231', '2018-10-21', '13970', '2', '1440-02-10', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('246', '1', '3', '3', '232', '2018-10-21', '258160', '2', '1440-02-10', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('247', '3', '20', '22', '233', '2018-10-28', '25000', '2', '1440-02-17', '', '1439-1440', '27', '17');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('248', '2', '15', '15', '234', '2018-11-09', '120', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('249', '3', '16', '16', '235', '2018-11-09', '93470', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('250', '2', '14', '14', '236', '2018-11-09', '68070', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('251', '2', '14', '14', '237', '2018-11-09', '273825', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('252', '2', '14', '14', '238', '2018-11-09', '167700', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('253', '3', '26', '19', '239', '2018-11-09', '610', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('254', '1', '2', '2', '240', '2018-11-09', '280', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('255', '3', '25', '17', '241', '2018-11-09', '1170', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('256', '2', '13', '13', '242', '2018-11-09', '6620', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('257', '1', '3', '3', '243', '2018-11-09', '107145', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('258', '3', '16', '16', '244', '2018-11-09', '321380', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('259', '1', '8', '8', '245', '2018-11-09', '670', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('260', '1', '9', '9', '246', '2019-11-09', '5850', '2', '1440-05-28', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('261', '1', '8', '8', '247', '2018-11-09', '3100', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('262', '1', '3', '3', '248', '2018-11-09', '182970', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('263', '2', '12', '12', '249', '2018-11-09', '7500', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('264', '2', '13', '13', '250', '2018-11-09', '2144', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('265', '1', '3', '3', '251', '2018-11-09', '4790', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('266', '1', '4', '4', '252', '2018-11-09', '926550', '2', '1440-02-29', '', '1439-1440', '27', '18');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('267', '2', '13', '13', '253', '2018-11-09', '13579', '2', '1440-02-29', '', '1439-1440', '27', '19');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('268', '1', '3', '3', '254', '2018-11-09', '226020', '2', '1440-02-29', '', '1439-1440', '27', '19');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('269', '3', '21', '23', '255', '2018-11-09', '16000', '2', '1440-02-29', '', '1439-1440', '27', '19');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('270', '3', '26', '19', '256', '2018-11-09', '550', '2', '1440-02-29', '', '1439-1440', '27', '19');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('271', '1', '3', '3', '257', '2018-11-09', '3340', '2', '1440-02-29', '', '1439-1440', '27', '19');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('272', '1', '8', '8', '258', '2018-11-09', '2100', '2', '1440-02-29', '', '1439-1440', '27', '19');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('273', '1', '3', '3', '259', '2018-11-09', '263255', '2', '1440-02-29', '', '1439-1440', '27', '19');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('274', '1', '3', '3', '260', '2019-02-10', '115276', '3', '1440-06-04', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('275', '1', '2', '2', '261', '2018-11-10', '29850', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('276', '1', '8', '8', '262', '2018-11-10', '130380', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('277', '2', '11', '11', '263', '2018-11-10', '27850', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('278', '2', '12', '12', '264', '2018-11-10', '4500', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('279', '1', '6', '6', '265', '2018-11-10', '5280', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('280', '1', '3', '3', '266', '2018-11-10', '47954', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('281', '1', '1', '1', '267', '2018-11-10', '66266', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('282', '3', '16', '16', '268', '2018-11-10', '89700', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('283', '1', '3', '3', '269', '2018-11-10', '6430', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('284', '1', '2', '2', '270', '2018-11-10', '37550', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('285', '2', '13', '13', '271', '2018-11-10', '1230', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('286', '1', '2', '2', '272', '2018-11-17', '40950', '3', '1440-03-08', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('287', '3', '26', '19', '273', '2018-11-17', '7860', '3', '1440-03-08', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('288', '3', '27', '25', '274', '2018-11-17', '3240', '3', '1440-03-08', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('289', '1', '3', '3', '275', '2018-11-10', '201563', '3', '1440-03-01', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('290', '2', '15', '15', '276', '2018-11-17', '1980', '3', '1440-03-08', '', '1439-1440', '27', '20');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('291', '3', '25', '17', '277', '2018-11-17', '1240', '3', '1440-03-08', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('292', '1', '6', '6', '278', '2019-02-04', '500', '3', '1440-05-28', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('293', '2', '15', '15', '279', '2018-11-17', '5100', '3', '1440-03-08', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('294', '1', '9', '9', '280', '2018-11-17', '17280', '3', '1440-03-08', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('295', '1', '8', '8', '281', '2018-11-17', '1500', '3', '1440-03-08', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('296', '2', '12', '12', '282', '2018-11-17', '5500', '3', '1440-03-08', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('297', '2', '12', '12', '283', '2018-11-17', '2000', '3', '1440-03-08', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('298', '2', '13', '13', '284', '2018-11-17', '374', '3', '1440-03-08', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('299', '1', '3', '3', '285', '2018-11-17', '2950', '3', '1440-03-08', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('300', '1', '8', '8', '286', '2018-11-17', '180', '3', '1440-03-08', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('301', '1', '4', '4', '287', '2018-11-17', '919180', '3', '1440-03-08', '', '1439-1440', '27', '21');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('302', '2', '13', '13', '288', '2018-11-17', '4736', '3', '1440-03-08', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('303', '2', '12', '12', '289', '2018-11-17', '25000', '3', '1440-03-08', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('304', '1', '3', '3', '290', '2018-12-08', '283222', '3', '1440-03-29', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('305', '1', '8', '8', '291', '2018-12-08', '3760', '3', '1440-03-29', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('306', '1', '2', '2', '292', '2018-12-08', '87150', '3', '1440-03-29', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('307', '1', '6', '6', '293', '2018-12-08', '2830', '3', '1440-03-29', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('308', '1', '1', '1', '294', '2018-12-08', '128123', '3', '1440-03-29', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('309', '1', '3', '3', '296', '2018-12-08', '4600', '3', '1440-03-29', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('310', '1', '3', '3', '297', '2018-12-08', '233910', '3', '1440-03-29', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('311', '1', '3', '3', '298', '2018-12-08', '4160', '3', '1440-03-29', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('312', '1', '3', '3', '295', '2018-12-08', '153430', '3', '1440-03-29', '', '1439-1440', '27', '22');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('313', '1', '5', '5', '299', '2018-12-10', '9405', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('314', '2', '13', '13', '300', '2018-12-10', '180', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('315', '1', '3', '3', '301', '2018-12-10', '67770', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('316', '3', '26', '19', '302', '2018-12-10', '18520', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('317', '3', '21', '23', '303', '2018-12-10', '2390', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('318', '1', '3', '3', '304', '2018-12-10', '22272', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('319', '3', '26', '19', '305', '2018-12-10', '470', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('320', '1', '1', '1', '306', '2018-12-10', '44560', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('321', '1', '2', '2', '307', '2018-12-10', '18200', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('322', '1', '8', '8', '308', '2018-12-10', '8106', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('323', '3', '25', '17', '309', '2018-12-10', '1340', '4', '1440-04-01', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('324', '2', '15', '15', '310', '2018-12-16', '7885', '4', '1440-04-07', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('325', '3', '16', '16', '311', '2018-12-16', '269900', '4', '1440-04-07', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('326', '1', '6', '6', '312', '2018-12-16', '4740', '4', '1440-04-07', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('327', '3', '26', '19', '313', '2018-12-16', '2300', '4', '1440-04-07', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('328', '2', '11', '11', '314', '2018-12-16', '27850', '4', '1440-04-07', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('329', '1', '9', '9', '315', '2018-12-16', '4580', '4', '1440-04-07', '', '1439-1440', '27', '23');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('330', '2', '13', '13', '316', '2019-01-02', '10930', '4', '1440-04-24', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('331', '1', '3', '3', '317', '2019-01-02', '140050', '4', '1440-04-24', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('332', '3', '16', '16', '318', '2019-01-02', '57720', '4', '1440-04-24', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('333', '1', '9', '9', '319', '2019-01-02', '5292', '4', '1440-04-24', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('334', '2', '12', '12', '320', '2019-01-02', '4500', '4', '1440-04-24', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('335', '1', '2', '2', '321', '2019-01-02', '10330', '4', '1440-04-24', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('336', '1', '8', '8', '322', '2019-01-02', '10950', '4', '1440-04-24', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('337', '2', '13', '13', '323', '2019-01-02', '5140', '4', '1440-04-24', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('338', '1', '3', '3', '324', '2019-01-02', '5290', '4', '1440-04-24', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('339', '1', '3', '3', '325', '2019-01-07', '50400', '4', '1440-04-29', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('340', '1', '2', '2', '326', '2019-01-07', '32200', '4', '1440-04-29', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('341', '2', '12', '12', '327', '2019-01-07', '7500', '4', '1440-04-29', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('342', '1', '4', '4', '328', '2019-01-07', '925550', '4', '1440-04-29', '', '1439-1440', '27', '24');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('343', '1', '3', '3', '329', '2019-01-07', '300702', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('344', '3', '21', '23', '330', '2019-01-07', '1100', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('345', '2', '12', '12', '331', '2019-01-07', '25000', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('346', '1', '6', '6', '332', '2019-01-07', '200', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('347', '1', '8', '8', '333', '2019-01-07', '6550', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('348', '1', '3', '3', '334', '2019-01-07', '260712', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('349', '1', '2', '2', '335', '2019-01-07', '2030', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('350', '2', '13', '13', '336', '2019-01-07', '8380', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('351', '1', '2', '2', '337', '2019-01-07', '173330', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('352', '1', '6', '6', '338', '2019-01-07', '2820', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('353', '1', '1', '1', '339', '2019-01-07', '69040', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('354', '1', '3', '3', '340', '2019-01-07', '269430', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('355', '1', '8', '8', '341', '2019-01-07', '4263', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('356', '2', '13', '13', '342', '2019-01-07', '15740', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('357', '1', '3', '3', '343', '2019-01-07', '2978', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('358', '1', '3', '3', '344', '2019-01-07', '289775', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('359', '3', '26', '19', '345', '2019-01-07', '6513', '4', '1440-04-29', '', '1439-1440', '27', '25');
INSERT INTO `jamia_expenses` (`id`, `expense_category_id`, `child_expense_id`, `sub_child_expense_id`, `bill_no`, `date`, `amount`, `arabic_month`, `arabic_date`, `comment`, `year`, `talimi_saal`, `page_num`) VALUES ('360', '1', '7', '7', '346', '2019-01-07', '13000', '4', '1440-04-29', '', '1439-1440', '27', '25');


#
# TABLE STRUCTURE FOR: language
#

DROP TABLE IF EXISTS `language`;

CREATE TABLE `language` (
  `phrase_id` int(11) NOT NULL AUTO_INCREMENT,
  `phrase` longtext COLLATE utf8_unicode_ci NOT NULL,
  `english` longtext COLLATE utf8_unicode_ci NOT NULL,
  `urdu` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`phrase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=571 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('1', 'class_routine', 'Class Routine', 'کلاس ضابط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('2', 'dashboard', 'Dashboard', 'ڈیش  بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('3', 'student', 'Student', 'طالب علم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('4', 'admit_student', 'Admit Student', ' داخلہ طالب علم ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('5', 'admit_bulk_student', 'Admit Bulk Student', 'بلک طالب علم کو داخل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('6', 'student_information', 'Student Information', 'طالب علم کی معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('7', 'class', 'Class', 'درجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('8', 'student_promotion', 'Student Promotion', 'طلبا کی پروموشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('9', 'teacher', 'Teacher', 'معلم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('10', 'parents', 'Parents', 'والدین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('11', 'manage_classes', 'Manage Classes', 'کلاسز انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('12', 'manage_sections', 'Manage Sections', 'حصے انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('13', 'subject', 'Subject', 'مضمون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('14', 'daily_attendance', 'Daily Attendance', 'روزان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('15', 'exam', 'Exam', 'امتحان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('16', 'exam_list', 'Exam List', 'امتحان فہرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('17', 'exam_grades', 'Exam Grades', 'امتحان گریڈز');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('18', 'manage_marks', 'Manage Marks', 'ترتیب نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('19', 'send_marks_by_sms', 'Send Marks By Sms', 'SMS کے ذریعے مارکس کا حساب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('20', 'tabulation_sheet', 'Tabulation Sheet', 'نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('21', 'accounting', 'Accounting', 'اکاونٹنگ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('22', 'create_student_payment', 'Create Student Payment', 'Student کی ادائیگی بنائیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('23', 'student_payments', 'Student Payments', 'Student کی ادائیگیاں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('24', 'expense', 'Expense', 'خرچ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('25', 'expense_category', 'Expense Category', 'اخراجات زمر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('26', 'library', 'Library', 'لائبریری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('27', 'transport', 'Transport', 'ٹرانسپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('28', 'dormitory', 'Dormitory', 'شیناگار');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('29', 'noticeboard', 'Noticeboard', 'نوٹس بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('30', 'message', 'Message', 'پیغام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('31', 'settings', 'Settings', 'ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('32', 'general_settings', 'General Settings', 'عام ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('33', 'sms_settings', 'Sms Settings', 'SMS کی ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('34', 'language_settings', 'Language Settings', 'زبان کی ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('35', 'account', 'Account', 'اکاؤنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('36', 'running_session', 'Running Session', 'سیشن چلانے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('37', 'edit_profile', 'Edit Profile', ' پروفائل ترمیم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('38', 'change_password', 'Change Password', 'پاس ورڈ تبدیل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('39', 'add_class_routine', 'Add Class Routine', 'کلاس معمول کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('40', 'section', 'Section', 'سیکشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('41', 'edit', 'Edit', 'تصیح');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('42', 'delete', 'Delete', 'حذف کرنا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('43', 'cancel', 'Cancel', 'منسوخ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('44', 'admin_dashboard', 'Admin Dashboard', 'ایڈمن ڈیش بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('45', 'event_schedule', 'Event Schedule', 'ایونٹ کے شیڈول');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('46', 'parent', 'Parent', 'ولدیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('47', 'attendance', 'Attendance', 'حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('48', 'add_student', 'Add Student', 'طالب علم کے لئے شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('49', 'addmission_form', 'Addmission Form', 'Addmission Form');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('50', 'name', 'Name', 'نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('51', 'value_required', 'Value Required', 'ویلیو مطلوب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('52', 'select', 'Select', 'منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('53', 'select_class_first', 'Select Class First', 'پہلے کلاس منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('54', 'roll', 'Serial  #', 'رول نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('55', 'birthday', 'DOB', 'سالگر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('56', 'gender', 'Gender', 'صنف');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('57', 'male', 'Male', 'مرد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('58', 'female', 'Female', 'خاتون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('59', 'address', 'Address', 'ایڈریس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('60', 'phone', 'Phone', 'موبائل نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('61', 'email', 'Email', 'ای میل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('62', 'password', 'Password', 'پاس ورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('63', 'transport_route', 'Transport Route', 'ٹرانسپورٹ روٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('64', 'photo', 'Photo', 'تصویر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('65', 'add_bulk_student', 'Add Bulk Student', 'بلک طالب علم ان کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('66', 'select_class', 'Select Class', 'کلاس منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('67', 'add_more_students', 'Add More Students', 'زیاد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('68', 'save_students', 'Save Students', 'طالب علموں کو مح');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('69', 'select_section', 'Select Section', 'سیکشن منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('70', 'add_new_student', 'Add New Student', 'نیا طالب علم  شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('71', 'all_students', 'All Students', 'تمام طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('72', 'options', 'Options', 'اختیارات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('73', 'mark_sheet', 'Mark Sheet', 'مارک شیٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('74', 'profile', 'Profile', ' پروفائل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('75', 'edit_student', 'Edit Student', 'Student کی تصیح');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('76', 'current_session', 'Current Session', 'موجود');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('77', 'promote_to_session', 'Promote To Session', 'اجلاس سے ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('78', 'promotion_from_class', 'Promotion From Class', 'کلاس سے پروموشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('79', 'promotion_to_class', 'Promotion To Class', 'کلاس میں پروموشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('80', 'select_all', 'Select All', 'تمام منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('81', 'select_none', 'Select None', 'کوئی بھی منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('82', 'average', 'Average', 'اوسط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('83', 'promote_slelected_students', 'Promote Slelected Students', 'منتخب طلبا کی پروموشن کریں ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('84', 'manage_teacher', 'Manage Teacher', 'ٹیچر انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('85', 'add_new_teacher', 'Add New Teacher', 'نیو ٹیچر شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('86', 'add_teacher', 'Add Teacher', 'استاد ان کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('87', 'edit_teacher', 'Edit Teacher', 'ٹیچر ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('88', 'sex', 'Sex', 'جنس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('89', 'marksheet_for', 'Marksheet For', 'Marksheet For');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('90', 'total_marks', 'Total Marks', 'مجموعی نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('91', 'average_grade_point', 'Average Grade Point', 'اوسط گریڈ پوائنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('92', 'print_marksheet', 'Print Marksheet', 'Print Marksheet');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('93', 'student_marksheet', 'Student Marksheet', 'طلباء ڈی ایم سی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('94', 'parent_phone', 'Parent Phone', 'والدین ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('95', 'all_parents', 'All Parents', 'تمام والدین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('96', 'add_new_parent', 'Add New Parent', 'نئے والدین کے لئے شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('97', 'profession', 'Profession', 'پیشہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('98', 'add_parent', 'Add Parent', 'داخلہ ولدیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('99', 'update', 'Update', 'اپ ڈیٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('100', 'manage_class', 'Manage Class', 'کلاس انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('101', 'class_list', 'Class List', 'کلاس کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('102', 'add_class', 'Add Class', 'کلاس شامل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('103', 'class_name', 'Class Name', 'کلاس نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('104', 'numeric_name', 'Numeric Name', 'نمبری نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('105', 'name_numeric', 'Name Numeric', 'نام نمبری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('106', 'select_teacher', 'Select Teacher', 'ٹیچر منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('107', 'edit_class', 'Edit Class', 'تصیح کلاس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('108', 'add_new_section', 'Add New Section', 'نیا سیکشن میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('109', 'section_name', 'Section Name', 'حصے کا نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('110', 'nick_name', 'Nick Name', 'نک نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('111', 'add_section', 'Add Section', 'سیکشن کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('112', 'manage_subject', 'Manage Subject', ' انتظام مضمون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('113', 'subject_list', 'Subject List', 'مضمون لسٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('114', 'add_subject', 'Add Subject', 'اندراج مضمون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('115', 'subject_name', 'Subject Name', 'نام مضمون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('116', 'edit_subject', 'Edit Subject', 'مضمون میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('117', 'day', 'Day', 'ڈے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('118', 'starting_time', 'Starting Time', 'وقت پر شروع');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('119', 'hour', 'Hour', 'قیامت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('120', 'minutes', 'Minutes', 'منٹس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('121', 'ending_time', 'Ending Time', 'وقت ختم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('122', 'edit_class_routine', 'Edit Class Routine', 'تصیح کلاس ضابط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('123', 'select_subject', 'Select Subject', 'مضمون منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('124', 'manage_daily_attendance', 'Manage Daily Attendance', 'روزان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('125', 'select_date', 'Select Date', 'تاریخ منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('126', 'select_month', 'Select Month', 'م');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('127', 'select_year', 'Select Year', 'چھانٹیں کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('128', 'manage_attendance', 'Manage Attendance', 'حاضری انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('129', 'manage_exam', 'Manage Exam', 'امتحان انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('130', 'add_exam', 'Add Exam', 'امتحان میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('131', 'exam_name', 'Exam Name', 'امتحان نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('132', 'date', 'Date', 'تاریخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('133', 'comment', 'Comment', 'کیفیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('134', 'edit_exam', 'Edit Exam', 'امتحان میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('135', 'manage_grade', 'Manage Grade', 'گریڈ انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('136', 'grade_list', 'Grade List', 'گریڈ کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('137', 'add_grade', 'Add Grade', 'گریڈ کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('138', 'grade_name', 'Grade Name', 'گریڈ نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('139', 'grade_point', 'Grade Point', 'گریڈ نقط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('140', 'mark_from', 'Mark From', 'سے Mark');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('141', 'mark_upto', 'Mark Upto', 'مارک تک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('142', 'manage_exam_marks', 'Manage Exam Marks', 'امتحان مارکس کو منظم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('143', 'select_exam', 'Select Exam', 'امتحان منتخب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('144', 'send_marks', 'Send Marks', 'مارکس کا حساب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('145', 'select_receiver', 'Select Receiver', 'وصول کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('146', 'students', 'Students', 'طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('147', 'select_a_class', 'Select A Class', 'A کلاس منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('148', 'select_an_exam', 'Select An Exam', 'ایک امتحان کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('149', 'view_tabulation_sheet', 'View Tabulation Sheet', 'ٹیبیولیشن شیٹ لنک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('150', 'subjects', 'Subjects', 'مضامین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('151', 'total', 'Total', 'کل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('152', 'create_single_invoice', 'Create Single Invoice', 'سنگل انوائس بنائیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('153', 'create_mass_invoice', 'Create Mass Invoice', 'ماس انوائس بنائیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('154', 'invoice_informations', 'Invoice Informations', 'انوائس کی معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('155', 'title', 'Title', 'عنوان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('156', 'description', 'Description', 'تفصیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('157', 'payment_informations', 'Payment Informations', 'ادائیگی کی معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('158', 'enter_total_amount', 'Enter Total Amount', 'کل رقم درج');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('159', 'payment', 'Payment', 'ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('160', 'enter_payment_amount', 'Enter Payment Amount', 'ادائیگی کی رقم درج');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('161', 'status', 'Status', 'سٹیٹس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('162', 'paid', 'Paid', 'ادا کی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('163', 'unpaid', 'Unpaid', 'بلا معاوض');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('164', 'method', 'Method', 'طریق');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('165', 'cash', 'Cash', 'نقد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('166', 'check', 'Check', 'چیک کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('167', 'card', 'Card', 'کارڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('168', 'add_invoice', 'Add Invoice', 'انوائس میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('169', 'unpaid_invoices', 'Unpaid Invoices', 'بلا معاوض');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('170', 'payment_history', 'Payment History', 'ادائیگی کی تاریخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('171', 'amount', 'Amount', 'رقم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('172', 'expenses', 'Expenses', 'اخراجات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('173', 'add_new_expense', 'Add New Expense', 'نئے اخراجات کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('174', 'category', 'Category', 'قسم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('175', 'add_expense', 'Add Expense', 'اخراجات میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('176', 'select_expense_category', 'Select Expense Category', 'منتخب اخراجات زمر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('177', 'add_new_expense_category', 'Add New Expense Category', 'شامل کریں نئے اخراجات زمر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('178', 'add_expense_category', 'Add Expense Category', 'اخراجات زمر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('179', 'edit_expense', 'Edit Expense', 'اخراجات میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('180', 'manage_library_books', 'Manage Library Books', 'کتب خانے کی کتابیں انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('181', 'book_list', 'Book List', 'کتاب کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('182', 'add_book', 'Add Book', 'کتاب شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('183', 'book_name', 'Book Name', 'کتاب کا نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('184', 'author', 'Author', 'مصن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('185', 'price', 'Price', 'قیمت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('186', 'available', 'Available', 'دستیاب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('187', 'unavailable', 'Unavailable', 'دستیاب ن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('188', 'manage_transport', 'Manage Transport', 'ٹرانسپورٹ کا انتظام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('189', 'transport_list', 'Transport List', 'ٹرانسپورٹ کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('190', 'add_transport', 'Add Transport', 'ٹرانسپورٹ شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('191', 'route_name', 'Route Name', 'روٹ نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('192', 'number_of_vehicle', 'Number Of Vehicle', 'گاڑی کا نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('193', 'route_fare', 'Route Fare', 'روٹ کرای');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('194', 'edit_transport', 'Edit Transport', 'ٹرانسپورٹ میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('195', 'manage_dormitory', 'Manage Dormitory', 'شیناگار انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('196', 'dormitory_list', 'Dormitory List', 'شیناگار کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('197', 'add_dormitory', 'Add Dormitory', 'شیناگار میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('198', 'dormitory_name', 'Dormitory Name', 'شیناگار نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('199', 'number_of_room', 'Number Of Room', 'کمر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('200', 'edit_dormitory', 'Edit Dormitory', 'شیناگار میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('201', 'manage_noticeboard', 'Manage Noticeboard', 'نوٹس بورڈ انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('202', 'noticeboard_list', 'Noticeboard List', 'نوٹس کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('203', 'add_noticeboard', 'Add Noticeboard', 'نوٹس بورڈ میں شامل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('204', 'notice', 'Notice', 'نوٹس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('205', 'add_notice', 'Add Notice', 'نوٹس کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('206', 'send_sms_to_all', 'Send Sms To All', 'سب پر SMS بھیجیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('207', 'yes', 'Yes', 'جی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('208', 'no', 'No', 'ن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('209', 'sms_service_not_activated', 'Sms Service Not Activated', 'ایس ایم ایس سروس چالو ن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('210', 'private_messaging', 'Private Messaging', 'ذاتی پیغام رسانی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('211', 'messages', 'Messages', 'پیغامات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('212', 'new_message', 'New Message', 'نیا پیغام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('213', 'write_new_message', 'Write New Message', 'نیا پیغام لکھیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('214', 'recipient', 'Recipient', 'وصول کنند');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('215', 'select_a_user', 'Select A User', 'A یوزر کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('216', 'write_your_message', 'Write Your Message', 'اپنا پیغام لکھیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('217', 'send', 'Send', 'حساب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('218', 'system_settings', 'System Settings', 'نظام کی ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('219', 'system_name', 'System Name', 'سسٹم کا نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('220', 'system_title', 'System Title', 'سسٹم کی سرخی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('221', 'paypal_email', 'Paypal Email', 'پے پال ای میل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('222', 'currency', 'Currency', 'کرنسی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('223', 'system_email', 'System Email', 'سسٹم کی ای میل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('224', 'select_running_session', 'Select Running Session', 'سیشن چلانے کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('225', 'language', 'Language', 'زبان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('226', 'text_align', 'Text Align', 'متن سیدھ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('227', 'save', 'Save', 'محفوظ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('228', 'update_product', 'Update Product', 'اپ ڈیٹ کی مصنوعات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('229', 'file', 'File', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('230', 'install_update', 'Install Update', 'اپ ڈیٹ کو انسٹال');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('231', 'theme_settings', 'Theme Settings', 'تھیم ترتیبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('232', 'default', 'Default', 'پ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('233', 'select_theme', 'Select Theme', 'تھیم منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('234', 'select_a_theme_to_make_changes', 'Select A Theme To Make Changes', 'تبدیلیاں کرنے کے لئے ایک تھیم منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('235', 'upload_logo', 'Upload Logo', 'اپ لوڈ کی علامت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('236', 'upload', 'Upload', 'اپ لوڈ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('237', 'select_a_service', 'Select A Service', 'ایک خدمت کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('238', 'not_selected', 'Not Selected', 'منتخب ن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('239', 'disabled', 'Disabled', 'معذور');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('240', 'clickatell_username', 'Clickatell Username', 'Clickatell رکنیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('241', 'clickatell_password', 'Clickatell Password', 'Clickatell پاس ورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('242', 'clickatell_api_id', 'Clickatell Api Id', 'Clickatell API ID');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('243', 'twilio_account', 'Twilio Account', 'Twilio اکاؤنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('244', 'authentication_token', 'Authentication Token', 'توثیق ٹوکن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('245', 'registered_phone_number', 'Registered Phone Number', 'رجسٹرڈ ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('246', 'manage_language', 'Manage Language', 'زبان انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('247', 'language_list', 'Language List', 'زبان کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('248', 'add_phrase', 'Add Phrase', 'جمل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('249', 'add_language', 'Add Language', 'زبان کا اضا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('250', 'option', 'Option', 'آپشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('251', 'edit_phrase', 'Edit Phrase', 'جمل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('252', 'delete_language', 'Delete Language', 'زبان چھپانا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('253', 'phrase', 'Phrase', 'جمل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('254', 'manage_profile', 'Manage Profile', 'پروفائل کا نظم ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('255', 'update_profile', 'Update Profile', 'اپ ڈیٹ پروفائل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('256', 'current_password', 'Current Password', 'موجودہ پاس ورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('257', 'new_password', 'New Password', 'نیا پاس ورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('258', 'confirm_new_password', 'Confirm New Password', 'نئے پاس ورڈ کی توثیق کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('259', 'login', 'Login', 'لاگ ان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('260', 'forgot_your_password', 'Forgot Your Password', 'پاس ورڈ بھول گیا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('261', 'reset_password', 'Reset Password', 'پاس ورڈ ری سیٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('262', 'return_to_login_page', 'Return To Login Page', 'پیج لاگ ان واپس جائیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('263', 'service_is_disabled', 'Service Is Disabled', 'سروس غیر ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('264', 'promote_to_selected_class', 'Promote To Selected Class', 'منتخب شد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('265', 'stay_in_present_class', 'Stay In Present Class', 'موجود');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('266', 'data_updated', 'Data Updated', 'ڈیٹا کو اپ ڈیٹ.');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('267', 'data_added_successfully', 'Data Added Successfully', 'معلومات کو کامیابی سے شامل کر د یے گیے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('268', 'edit_grade', 'Edit Grade', 'گریڈ میں ترمیم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('269', 'manage_attendance_of_class', 'Manage Attendance Of Class', 'کلاس کی حاضری انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('270', 'present', 'Present', 'حاضر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('271', 'absent', 'Absent', 'غائب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('272', 'update_attendance', 'Update Attendance', 'اپ ڈیٹ حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('273', 'undefined', 'Undefined', 'مبہم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('274', 'back', 'Back', 'واپس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('275', 'save_changes', 'Save Changes', 'تبدیلیاں محفوظ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('276', 'data_deleted', 'Data Deleted', 'ڈیٹا حذف کردیا گیا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('277', 'academic_syllabus', 'Academic Syllabus', 'تعلیمی نصاب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('278', 'add_academic_syllabus', 'Add Academic Syllabus', 'تعلیمی نصاب میں شامل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('279', 'uploader', 'Uploader', 'اپ لوڈر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('280', 'upload_academic_syllabus', 'Upload Academic Syllabus', 'اپ لوڈ کریں تعلیمی نصاب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('281', 'upload_syllabus', 'Upload Syllabus', 'اپ لوڈ کریں نصاب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('282', 'syllabus_uploaded', 'Syllabus Uploaded', 'نصاب اپ لوڈ کرد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('283', 'download', 'Download', 'لوڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('284', 'remove', 'Remove', 'دور');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('285', 'print', 'Print', 'پرنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('286', 'teacher_dashboard', 'Teacher Dashboard', 'ٹیچر ڈیش بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('287', 'study_material', 'Study Material', 'تربیتی مواد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('288', 'teacher_list', 'Teacher List', 'ٹیچر لسٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('289', 'manage_class_routine', 'Manage Class Routine', 'کلاس ضابط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('290', 'class_routine_list', 'Class Routine List', 'کلاس معمول کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('291', 'add_study_material', 'Add Study Material', 'تربیتی مواد شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('292', 'file_type', 'File Type', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('293', 'select_file_type', 'Select File Type', 'منتخب ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('294', 'image', 'Image', 'تصویر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('295', 'doc', 'Doc', 'ڈاکٹر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('296', 'pdf', 'Pdf', 'پی ڈی ای');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('297', 'excel', 'Excel', 'ایکسل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('298', 'other', 'Other', 'دیگر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('299', 'manage_promotion', 'Manage Promotion', 'پروموشن کا نظم کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('300', 'select_class_for_promotion_to_and_from', 'Select Class For Promotion To And From', 'اور سے پروموشن کے لئے کلاس کو منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('301', 'students_of_class', 'Students Of Class', 'کلاس کے طالب علموں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('302', 'enroll_to_class', 'Enroll To Class', 'کلاس اندراج کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('303', 'add_a_row', 'Add A Row', 'ایک قطار میں شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('304', 'marks_obtained', 'Marks Obtained', 'حاصل کردہ نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('305', 'marks_updated', 'Marks Updated', 'مارکس تاز');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('306', 'marks_for', 'Marks For', 'کے لئے نشان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('307', 'attendance_for_class', 'Attendance For Class', 'کلاس کے لئے حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('308', 'print_tabulation_sheet', 'Print Tabulation Sheet', 'پرنٹ ٹیبیولیشن شیٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('309', 'receiver', 'Receiver', 'وصول');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('310', 'please_select_receiver', 'Please Select Receiver', 'وصول برا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('311', 'session_changed', 'Session Changed', 'سیشن تبدیل کر دیا گیا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('312', 'attendance_updated', 'Attendance Updated', 'حاضری تاز');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('313', 'study_material_info_saved_successfuly', 'Study Material Info Saved Successfuly', 'تربیتی مواد ان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('314', 'edit_study_material', 'Edit Study Material', 'تصیح تربیتی مواد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('315', 'parent_dashboard', 'Parent Dashboard', 'والدین کا ڈیش بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('316', 'exam_marks', 'Exam Marks', 'امتحان مارکس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('317', 'total_mark', 'Total Mark', 'کل مارک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('318', 'mark_obtained', 'Mark Obtained', 'حاصل کردہ نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('319', 'manage_invoice/payment', 'Manage Invoice/payment', 'انتظام کریں انوائس / ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('320', 'invoice/payment_list', 'Invoice/payment List', 'انوائس / ادائیگی کی ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('321', 'student_dashboard', 'Student Dashboard', 'طالب علم کا ڈیش بورڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('322', 'obtained_marks', 'Obtained Marks', 'حاصل کردہ نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('323', 'highest_mark', 'Highest Mark', 'سب سے زیاد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('324', 'grade', 'Grade', 'تقدیر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('325', 'take_payment', 'Take Payment', 'ادائیگی کے لے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('326', 'view_invoice', 'View Invoice', 'لنک انوائس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('327', 'creation_date', 'Creation Date', 'بنانے کی تاریخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('328', 'payment_to', 'Payment To', 'کرنے کے لئے ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('329', 'bill_to', 'Bill To', 'کا بل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('330', 'total_amount', 'Total Amount', 'مجموعی رقم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('331', 'paid_amount', 'Paid Amount', 'ادا کی گئی رقم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('332', 'due', 'Due', 'وج');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('333', 'amount_paid', 'Amount Paid', 'رقم ادا کر دی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('334', 'payment_successfull', 'Payment Successfull', 'ادائیگی کامیاب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('335', 'add_invoice/payment', 'Add Invoice/payment', 'شامل کریں انوائس / ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('336', 'invoices', 'Invoices', 'انوائس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('337', 'action', 'Action', 'عمل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('338', 'required', 'Required', 'مطلوب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('339', 'info', 'Info', 'معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('340', 'view_academic_performance', 'View Academic Performance', 'تعلیمی کارکردگی دیکھیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('341', 'phrase_list', 'Phrase List', 'جمل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('342', 'update_phrase', 'Update Phrase', 'اپ ڈیٹ کے جملے سے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('343', 'edit_invoice', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('344', 'students_added', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('345', 'student_already_enrolled', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('346', 'new_enrollment_successfull', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('347', 'reply_message', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('348', 'dob_in_words', 'DOB in Words', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('349', 'caste', 'Caste or Tribe', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('350', 'admission_date', 'Admission Date', ' داخلہ تاریخ  ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('351', 'status_first', '1st Mtg', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('352', 'status_last', '2nd Mtg', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('353', 'prev_atd', 'Prev Attd', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('354', 'curr_atd', 'Curr Attd', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('355', 'total_atd', 'TotalAttd', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('356', 'fines', 'Fines', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('357', 'remarks', 'Remarks', 'کیفیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('359', 'current_address', '', 'موجودہ پتہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('360', 'permanent_address', '', 'مستقل پتہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('361', 'religion', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('362', 'muslim', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('363', 'non_muslim', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('364', 'nic', 'NIC', 'شناختی کارڈ نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('365', 'blood_group', '', 'بلڈ گروپ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('366', 'entry_test_marks', '', 'امتحان داخلہ نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('367', 'designation', '', 'نامزد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('368', 'student_wise', '', '');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('369', 'total_income', '', 'مجموعی امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('370', 'logout', '', 'چھوڑنا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('371', 'total_male_students', '', 'تمام طلبہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('372', 'total_female_students', '', 'تمام طالبات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('373', 'countries', '', 'مما لک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('374', 'manage_countries', '', 'انتظام مما لک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('375', 'country_details', '', 'تفصیل ممالک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('376', 'add_country', '', 'ملک شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('377', 'serial_no', '', 'نمبر شمار');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('378', 'country', '', 'ملک');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('379', 'data_updated_successfully', '', 'معلومات کو کامیابی سے اپ ڈیٹ کر د یا گیا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('380', 'add_province', '', 'صوبہ شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('381', 'province', '', 'صوبہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('382', 'province_details', '', 'صوبے کی تفصیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('383', 'select_country', '', 'ملک کا انتخاب کیجئے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('384', 'edit_province', '', 'صوبے کی ترمیم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('385', 'districts', '', 'اضلاع');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('386', 'manage_districts', '', 'انتظام اضلاع');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('387', 'district_details', '', 'تفصیل اضلاع');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('388', 'add_district', '', 'ضلع  شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('389', 'select_province', '', 'صوبہ منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('390', 'district_name', '', 'ضلع کا نام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('391', 'select_country_first', '', 'پہلا ملک منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('392', 'district', '', 'ضلع');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('393', 'branch', '', 'شاخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('394', 'select_branch', '', 'شاخ منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('395', 'manage_section', '', 'سیکشن  انتظام کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('396', 'submit', '', 'داخل کرنا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('397', 'personal_info', '', 'ذاتی معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('398', 'address_info', '', 'معلومات رہائش');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('399', 'reg_no', '', 'رجسٹریشن نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('400', 'dob', '', 'تاریخ پیدائش');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('401', 'admit_class', 'Admit Class', 'مطلوبہ درجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('402', 'class_roll', '', 'درجہ رول نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('403', 'select_image', 'Select Image', 'تصویر منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('404', 'next', '', 'اگلے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('405', 'previous', '', 'پچھلا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('406', 'select_province_first', '', 'پہلے صوبہ منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('407', 'last_class_attended', '', ' آخری پاس کردہ درجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('408', 'school_name', '', 'نام مدرسہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('409', 'parent_data', '', ' معلومات والدین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('410', 'class_number', '', 'کلاس نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('411', 'edit_form', '', 'فارم تصیح');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('412', 'withdraw', '', 'خارج کرنا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('413', 'remark', 'Remarks', 'رمارکس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('414', 'checked_by', '', 'چیک باٰیٰ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('415', 'prepared_by', '', 'تیارکرنےوالا');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('416', 'reason', '', 'وجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('417', 'withdraw_date', '', 'تاریخ خارج');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('418', 'withdraw_student', '', 'خارج طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('419', 'users', 'Users', 'صارفین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('420', 'user', 'User', 'صارف');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('421', 'add_user', 'Add User', 'صارف شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('422', 'user_type', '', 'صارف کی قسم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('423', 'admin', '', 'ایڈمن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('424', 'accountant', '', 'اکاؤنٹنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('425', 'examiner', '', 'جائزہ کار');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('426', 'librarian', '', 'لائبریرین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('427', 'select_user', 'Select User', 'صارف کا انتخاب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('428', 'system_users', 'System Users', 'صارفین نظام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('429', 'main_branch', 'Main Branch', 'مرکزی شاخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('430', 'select_branch_first', 'Select Branch First', 'پھلے شاخ منتخب کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('431', 'new_students', 'New Students', 'جدید طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('432', 'old_students', 'Old Students', 'قدیم طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('433', 'marks', 'Marks', 'نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('434', 'session', 'Session', 'سیشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('435', 'admit_student_through_excel', 'admit student through excel ', 'داخلہ طلباء بذریعہ ایکسل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('436', 'select_excel_file', '', ' منتخب ایکسل فایل ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('437', 'exams', '', 'امتحانات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('438', 'talimi_saal', 'Educational Year', 'تعلیمی سال');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('439', 'staff', '', 'خادمین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('440', 'staff_managment', '', 'ترتیبات خادمین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('441', 'contract_type', '', 'قسم معاہدہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('443', 'employee_type', '', 'اقسام خادم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('444', 'employee_type_list', '', 'فہرست اقسام خادمین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('445', 'add_new_employee', '', 'نیاءخادم شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('446', 'type', '', 'قسم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('447', 'edit_employee_type', '', 'تصیح اقسام خادم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('448', 'contract', '', 'کنٹریکٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('449', '-select-', '', '-منتخب کریں-');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('450', 'joining_date', '', 'تاریخ شمولیت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('451', 'social_links', '', 'سماجی روابط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('452', 'add_employee', '', 'خادم کو داخل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('453', 'edit_employee', '', 'تصیح خادم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('454', 'print_data_detail', '', 'تفصیلات پرنٹ کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('455', 'edit_image', '', 'تصویر تبدیل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('456', 'student_report', '', 'طلباء رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('457', 'exam_roll', '', 'امتحانی رول نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('458', 'student_exam_roll', '', 'طلباء امتحانی نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('459', 'exam_roll_report', '', 'امتحانی نمبر رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('460', 'create', '', ' بنائے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('461', 'student_exam_roll_record', '', 'فہرست رول نمبربرائے جائزات وامتحانات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('462', 'signature', '', 'دستخط');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('463', 'error_message', '', 'پیغام غلطی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('464', 'student_card', '', 'طلباء کارڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('465', 'students_information', '', 'معلومات طلباء');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('466', 'single_tabulation_sheet', '', 'انفرادی نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('467', 'percentage', '', 'فیصد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('468', 'position', '', 'پوزیشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('469', 'fail', '', 'راسب');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('470', 'exam_attendance', '', 'امتحانی حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('471', 'class_attendance', '', 'درجہ حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('472', 'result', '', 'نتیجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('473', 'sign_educator', '', 'امین ادارة التعلیم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('474', 'single_marksheet', 'Single Marksheet', 'انفرادی ڈی ایم سی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('475', 'marksheet', 'Marksheet', 'نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('476', 'class_position', '', 'کلاس پوزیشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('477', 'highest_marks', '', 'سب سے ذیادہ نمبرات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('478', 'combine_tabulation_sheet', '', 'اجتماعی نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('479', 'combine_marksheet', '', 'اجتماعی ڈی ایم سی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('480', 'annual_marksheet', '', 'سالا نہ ڈی ایم سی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('481', 'results', '', 'نتائیج');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('482', 'single_result', '', 'انفرادی نتیجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('483', 'multiple_result', '', 'اجتماعی نتیجہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('484', 'award_list', '', 'نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('485', 'award_list_single', '', 'انفرادی نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('486', 'award_list_multiple', '', 'اجتماعی نتیجہ فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('487', 'form_hifz_ahadees', '', 'فارم برائے حفظ احادیث');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('488', 'subject_attendance', '', 'حاضری مضامین');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('489', 'subject_attendance_report', '', 'رپورٹ مضامین حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('490', 'show_report', '', 'رپورٹ دکھائیں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('491', 'class_attendance_report', '', 'کلاس حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('492', 'month', '', 'مہینہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('493', 'takrar_attendance', '', ' تکرار حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('494', 'exam_report_form', '', 'فارم برائے شفوی امتحان');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('495', 'takrar_attendance_report', '', 'تکرار حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('496', 'study_attendance', '', 'مطالعہ حاضری');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('497', 'study_attendance_report', '', 'مطالعہ حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('498', 'annual_attendance_report', '', 'سالانہ حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('499', 'monthly_attendance_report', '', 'ماہانہ حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('500', 'leave', '', 'رخصت');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('501', 'friday_attendance', '', 'حاضری بروز جمعہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('502', 'friday_attendance_report', '', 'جمعہ حاضری رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('503', 'year', '', 'سال');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('504', 'annual_positions', '', 'سالانہ پوزیشن');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('505', 'mid_exam', '', 'چارنیم ماہی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('506', 'final_exam', '', 'سالانہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('507', 'form_inzibati_karwaie', '', 'انضباتی کارروائی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('508', 'student_search', '', 'تلاش طلبہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('509', 'card_expiration_date', '', 'کارڈ تاریخ تنسیخ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('510', 'service_card', '', 'سروس کارڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('511', 'data_form', '', 'ڈیٹا فارم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('512', 'guardian', '', 'سرپرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('513', 'add_guardian', '', 'سرپرست داخل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('514', 'student_fee', '', 'طلبہ فیس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('515', 'student_fee_info', '', 'طلبہ فیس معلومات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('516', 'monthly_fee', '', 'ماہانہ ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('517', 'Sponsor', '', 'کفیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('518', 'beneficiary', '', 'متکفل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('519', 'sponsor_list', '', 'کفیل فہرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('520', 'add_sponsor', '', 'داخلہ کفیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('521', 'student_transaction', '', 'طلبہ فیس ادائیگی');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('522', 'paid_payment', '', 'وصول شدہ رقم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('523', 'remaining', '', 'بقایا رقم');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('524', 'student_list', '', 'طلبہ فہرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('525', 'edit_exam_roll_number', '', 'تصیح امتحانی نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('526', 'self_payment', '', 'ذاتی تعاون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('527', 'detail', '', 'تفصیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('528', 'fee_invoice', '', 'فیس رسید');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('529', 'transaction_list', '', 'ادائیگی فہرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('530', 'class_fee_record', '', 'کلاس فیس ریکارڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('531', 'monthly', '', 'ماہانہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('532', 'student_paid_fee_record', '', 'طلبہ اداشدہ فیس ریکارڈ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('533', 'beneficiary_report', '', 'کفالت رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('534', 'sponsor_name', '', 'نام کفیل');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('535', 'sponsor_monthly_help', '', 'زرکفالت ماہانہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('536', 'beneficiary_student_fee_report', '', 'کفالت شدہ طلبہ فیس رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('537', 'jamia_expenses', '', 'جامعہ اخراجات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('538', 'jamia_expenses_category', '', 'جامعہ اخراجات اقسام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('539', 'expnese_category_list', '', 'اقسام اخراجات فہرست');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('540', 'add_category', '', 'داخل اقسام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('541', 'expenses_category_print', '', 'گوشوارا پرنٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('542', 'goshwara', '', 'گوشواراہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('543', 'empty_months_report', '', 'خالی ماہانہ رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('544', 'reports', '', 'رپورٹس');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('545', 'total_class_fee_report', '', 'مجموعی کلاس فیس رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('546', 'branch_fee_report', '', 'شاخ فیس رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('547', 'expenses_category', '', 'اقسام اخراجات');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('548', 'expneses_report', '', 'اخراجات رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('549', 'scholorship', '', 'وظیفہ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('550', 'in_subject_of', '', 'بابت برائے');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('551', 'jamia_expenses_report', '', 'جامعہ اخراجات رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('552', 'expenses_type', '', 'اقسام خرچ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('553', 'add_expense_type', '', 'شامل اقسام خرچ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('554', 'expenses_mad', '', 'مد اقسام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('555', 'add_expenses_mad', '', 'مد اقسام شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('556', 'khata_banam', '', 'کھاتہ بنام');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('557', 'bill_no', '', 'بل نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('558', 'page_no', '', 'صفحہ نمبر');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('559', 'jamia_income', '', 'جامعہ امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('560', 'income_category', '', 'اقسام امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('561', 'add_income_type', '', 'اقسام امد شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('562', 'update_income_type', '', 'تصیح اقسام امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('563', 'add_income', '', 'امد شامل کریں');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('564', 'income', '', 'امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('565', 'income_type', '', 'اقسام امد');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('566', 'income_report', '', 'امد رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('567', 'assistant_name', '', 'نام معاون');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('568', 'database_backup', '', 'ڈیٹا بیس بیک اپ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('569', 'months_expnese_report', '', 'مہینہ ٹو مہینہ رپورٹ');
INSERT INTO `language` (`phrase_id`, `phrase`, `english`, `urdu`) VALUES ('570', 'category_expnese_report', '', 'اقسام خرچ رپورٹ');


#
# TABLE STRUCTURE FOR: noticeboard
#

DROP TABLE IF EXISTS `noticeboard`;

CREATE TABLE `noticeboard` (
  `notice_id` int(11) NOT NULL AUTO_INCREMENT,
  `notice_title` longtext COLLATE utf8_unicode_ci NOT NULL,
  `notice` longtext COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `show_on_website` int(11) DEFAULT NULL,
  `image` longtext COLLATE utf8_unicode_ci,
  `create_timestamp` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: page_lock
#

DROP TABLE IF EXISTS `page_lock`;

CREATE TABLE `page_lock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `year` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('1', '1', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('2', '2', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('3', '3', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('4', '4', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('5', '5', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('6', '6', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('7', '7', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('8', '8', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('9', '9', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('10', '10', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('11', '11', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('12', '12', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('13', '13', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('14', '14', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('15', '15', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('16', '16', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('17', '17', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('18', '18', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('19', '19', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('20', '20', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('21', '21', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('22', '22', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('23', '23', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('24', '24', '0', '1439-1440');
INSERT INTO `page_lock` (`id`, `number`, `status`, `year`) VALUES ('25', '25', '1', '1439-1440');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`settings_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('1', 'system_name', 'جامعہ عثمانیہ پشاور');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('2', 'system_title', 'جامعہ عثمانیہ پشاور');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('3', 'address', 'Fabo Nawshehra Pakistan');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('4', 'phone', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('5', 'paypal_email', 'none');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('6', 'currency', 'money');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('7', 'system_email', 'imsunny37@gmail.com');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('11', 'language', 'urdu');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('12', 'text_align', 'right-to-left');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('13', 'clickatell_user', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('14', 'clickatell_password', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('15', 'clickatell_api_id', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('16', 'skin_colour', 'default');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('17', 'twilio_account_sid', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('18', 'twilio_auth_token', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('19', 'twilio_sender_phone_number', '');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('20', 'active_sms_service', 'disabled');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('21', 'running_year', '1439-1440');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('22', 'absent_message', ' آپکا بچہ آج غیر حاضر ہے۔');
INSERT INTO `settings` (`settings_id`, `type`, `description`) VALUES ('23', 'talimi_saal', '27');


#
# TABLE STRUCTURE FOR: sub_child_expense_category
#

DROP TABLE IF EXISTS `sub_child_expense_category`;

CREATE TABLE `sub_child_expense_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf8 NOT NULL,
  `child_expense_id` int(11) NOT NULL,
  `comment` longtext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('1', 'بجلی', '1', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('2', 'گیس،ایندھن', '2', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('3', 'مطبخ', '3', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('4', 'تنخواہ', '4', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('5', 'خرچہ امتحانات', '5', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('6', 'ٹیلیفون،فیکس', '6', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('7', 'ڈاک', '7', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('8', 'امدورفت', '8', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('9', 'سٹیشنری', '9', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('10', 'کتب', '10', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('11', 'العصر', '11', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('12', 'وظایف', '12', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('13', 'ضیافت', '13', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('14', 'تقریبات', '14', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('15', 'متفرقات', '15', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('16', 'تعمیرات', '16', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('17', 'اخبار', '25', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('18', 'خریداری زمین', '17', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('19', 'مرمت', '26', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('20', 'مرمت بلڈنگ', '18', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('21', 'سنیٹری', '19', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('22', 'دفتری آلات', '20', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('23', 'برقی آلات', '21', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('24', 'فرنیچر', '22', '');
INSERT INTO `sub_child_expense_category` (`id`, `name`, `child_expense_id`, `comment`) VALUES ('25', 'وفاق المدارس', '27', '');


